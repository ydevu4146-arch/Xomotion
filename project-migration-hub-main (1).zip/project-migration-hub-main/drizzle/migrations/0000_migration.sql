CREATE TABLE public.quote_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  package text NOT NULL,
  full_name text NOT NULL,
  email text NOT NULL,
  company text,
  services text[] NOT NULL DEFAULT '{}',
  quantity text,
  budget text,
  timeline text,
  details text,
  country text NOT NULL DEFAULT 'IN'
);
GRANT ALL ON public.quote_requests TO service_role;
ALTER TABLE public.quote_requests ENABLE ROW LEVEL SECURITY;