DROP POLICY "public read" ON public.media_overrides;
CREATE POLICY "published portfolio read" ON public.media_overrides
FOR SELECT TO anon, authenticated
USING (slot IN (
  'work-1.mp4', 'work-2.mp4', 'work-3.mp4',
  'work-4.mp4', 'work-5.mp4', 'work-6.mp4',
  'long-1.mp4', 'long-2.mp4', 'long-3.mp4',
  'design-social-media.jpg', 'design-brand-identity.jpg',
  'design-marketing-creative.jpg', 'design-youtube-thumbnail.jpg',
  'design-product-ad.jpg', 'design-promo-poster.jpg',
  'design-instagram-carousel.jpg', 'design-ecommerce.jpg'
));
CREATE POLICY "admin read" ON public.media_overrides
FOR SELECT TO authenticated
USING (public.has_role((SELECT auth.uid()), 'admin'::public.app_role));

DROP POLICY "portfolio read" ON storage.objects;
CREATE POLICY "portfolio owner read" ON storage.objects
FOR SELECT TO authenticated
USING (
  bucket_id = 'portfolio'
  AND owner_id = (SELECT auth.uid()::text)
  AND public.has_role((SELECT auth.uid()), 'admin'::public.app_role)
);