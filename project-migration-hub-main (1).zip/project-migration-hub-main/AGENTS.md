<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Migration architecture

<!-- AGENT-MEMORY:BEGIN -->
- Keep the original progress-bar intro and hero reveal in XoMotionSite; its timers must clean up on unmount without changing homepage layout.
- Keep long-form preview playback in its existing animation loop, with video refs and source-aware playback state, so the focused card follows the stack and uploaded replacements resume automatically.
- Use the shared preview-activity observer for portfolio loops and defer preview video sources until the section is near view, to avoid eager downloads and hidden-tab decoding.
- Public media replacement reads must use an explicit published-card slot allowlist; keep it aligned with portfolio cards so arbitrary entries are not exposed.
- Private portfolio storage reads require both administrator status and matching uploader ownership; visitors use only published signed links, never bucket listing or link creation.
<!-- AGENT-MEMORY:END -->

