# Roadmap
- [x] Restore the original loading animation and remove all sample reviews, retaining the six supplied reviews
- [x] Migrate studio site from archive
- [x] Owner can upload videos/images to Short form, Long form, Graphic design cards (click card -> upload)
- [x] Long-form front-card videos autoplay and loop, pausing behind the open player or outside the section
- [x] Improve portfolio loading and animation smoothness; verify mobile and desktop behavior
- [ ] Existing quote requests import (waiting on export)
