import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import gsap from 'gsap';
import {
  SHORT_FORM_SPEED,
  formatProjectCounter,
  getCarouselGap,
  getContinuousCarouselPose,
  getContinuousCarouselSlot,
  getFocusedCarouselIndex,
  getRelativeCarouselSlot,
  getSwipeStep,
  shouldCarouselVideoPlay,
  wrapProjectIndex,
} from '@/lib/motionHelpers';
import { mediaUrl } from '@/lib/media';
import { useMediaOverrides, slotOf } from '@/lib/media-overrides';
import { UploadSlotButton } from '@/components/UploadSlotButton';
import { observePreviewActivity, preparePreviewVideo } from '@/lib/preview-performance';

const WORK_PROJECTS = [
  { id: 'talking-head', categoryLabel: 'TALKING HEAD', videoSrc: mediaUrl('work-1.mp4'), posterSrc: mediaUrl('thumb-1.jpg') },
  { id: 'business-coaches', categoryLabel: 'BUSINESS COACHES', videoSrc: mediaUrl('work-2.mp4'), posterSrc: mediaUrl('thumb-2.jpg') },
  { id: 'healthcare-videos', categoryLabel: 'HEALTHCARE VIDEOS', videoSrc: mediaUrl('work-3.mp4'), posterSrc: mediaUrl('thumb-3.jpg') },
  { id: 'real-estate', categoryLabel: 'REAL ESTATE', videoSrc: mediaUrl('work-4.mp4'), posterSrc: mediaUrl('thumb-4.jpg') },
  { id: 'd2c-beauty-products', categoryLabel: 'D2C BEAUTY PRODUCTS', videoSrc: mediaUrl('work-5.mp4'), posterSrc: mediaUrl('thumb-5.jpg') },
  { id: 'e-commerce', categoryLabel: 'E-COMMERCE', videoSrc: mediaUrl('work-6.mp4'), posterSrc: mediaUrl('thumb-6.jpg') },
];

const TOTAL = WORK_PROJECTS.length;
const CLOSE_MS = 320;
const DRAG_THRESHOLD = 6;
/** Max fling speed after a drag, in videos per second. */
const MAX_FLING = 4;

/**
 * SHORT-FORM VIDEOS: the original 3D curved carousel, now drifting endlessly
 * right → left. One rAF loop owns a fractional `position`; each frame every card
 * gets a pose blended between the fixed slot poses. Six cards cover slots
 * −3…+3 and wrap only at the invisible far slots, so no duplicates are needed.
 */
export default function ShortFormSection() {
  const media = useMediaOverrides();
  const sectionRef = useRef<HTMLElement | null>(null);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const titleRef = useRef<HTMLDivElement | null>(null);
  const cardRefs = useRef<Array<HTMLDivElement | null>>([]);
  const videoRefs = useRef<Array<HTMLVideoElement | null>>([]);
  const [activeProject, setActiveProject] = useState(0);
  const pausedRef = useRef(false);
  const suppressClickRef = useRef(false);
  const nudgeRef = useRef<(dir: number) => void>(() => {});

  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [closing, setClosing] = useState(false);
  const lastTriggerRef = useRef<HTMLDivElement | null>(null);
  const closeBtnRef = useRef<HTMLButtonElement | null>(null);
  const closeTimerRef = useRef<number | undefined>(undefined);
  const swipeStartRef = useRef<{ x: number; y: number } | null>(null);
  const swipedRef = useRef(false);

  useEffect(() => {
    const section = sectionRef.current;
    const stage = stageRef.current;
    if (!section || !stage) return;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const cleanups: Array<() => void> = [];

    let isMobile = window.innerWidth <= 768;
    let frameWidth = 292;
    let gap = 48;
    let stepX = 340;
    const measure = () => {
      isMobile = window.innerWidth <= 768;
      frameWidth = cardRefs.current[0]?.offsetWidth || (isMobile ? 242 : 292);
      gap = getCarouselGap(window.innerWidth);
      stepX = isMobile ? Math.round(frameWidth * 0.92 + gap) : frameWidth + gap;
    };
    measure();

    let position = 0;
    let velocity = reduceMotion ? 0 : SHORT_FORM_SPEED;
    const nudge = { v: 0 };
    let nudgeTarget = 0;
    let focused = 0;
    const playing: boolean[] = new Array(TOTAL).fill(false);
    const filters: string[] = new Array(TOTAL).fill('');
    const sources: Array<string | null> = new Array(TOTAL).fill(null);
    let inView = false;

    const setPlaying = (i: number, play: boolean) => {
      const video = videoRefs.current[i];
      if (!video) return;
      const source = video.dataset['src'];
      if (inView && source) preparePreviewVideo(video, source);
      if (sources[i] !== source) {
        sources[i] = source ?? null;
        playing[i] = false;
      }
      if (playing[i] === play) return;
      playing[i] = play;
      if (play) {
        video.playbackRate = 1;
        video.play()?.catch(() => {
          playing[i] = false;
        });
      } else {
        video.pause();
      }
    };

    const render = () => {
      const pos = position + nudge.v;
      const paused = pausedRef.current;
      for (let i = 0; i < TOTAL; i++) {
        const card = cardRefs.current[i];
        if (!card) continue;
        const slot = getContinuousCarouselSlot(i, pos, TOTAL);
        const p = getContinuousCarouselPose(slot, frameWidth, gap, isMobile);
        const s = card.style;
        s.transform = `translate3d(${p.x.toFixed(2)}px,0,0) rotateY(${p.rotateY.toFixed(3)}deg) scale(${p.scale.toFixed(4)})`;
        s.opacity = p.opacity.toFixed(3);
        s.zIndex = String(p.zIndex);
        s.pointerEvents = Math.abs(slot) <= 1.5 ? 'auto' : 'none';
        const blur = Math.round(p.blur * 10) / 10;
        const bright = Math.round(p.brightness * 100) / 100;
        const filter = blur === 0 && bright === 1 ? 'none' : `blur(${blur}px) brightness(${bright})`;
        if (filter !== filters[i]) {
          s.filter = filter;
          filters[i] = filter;
        }
        setPlaying(i, inView && !paused && shouldCarouselVideoPlay(slot));
      }
      const next = getFocusedCarouselIndex(pos, TOTAL);
      if (next !== focused) {
        const dir = wrapProjectIndex(next - focused, TOTAL) === 1 ? 1 : -1;
        focused = next;
        setActiveProject(next);
        if (titleRef.current) {
          gsap.fromTo(
            titleRef.current,
            { opacity: 0, y: 10, x: dir * 16 },
            { opacity: 1, y: 0, x: 0, duration: reduceMotion ? 0.01 : 0.52, ease: 'power3.out', overwrite: true },
          );
        }
      }
    };

    // drag / swipe
    let pointerId: number | null = null;
    let startX = 0;
    let startY = 0;
    let lastX = 0;
    let lastT = 0;
    let dragging = false;
    let dragVel = 0;

    let raf = 0;
    let last = 0;
    const frame = (now: number) => {
      const dt = last ? Math.min(0.05, (now - last) / 1000) : 0;
      last = now;
      if (!dragging) {
        const paused = pausedRef.current;
        const target = paused || reduceMotion ? 0 : SHORT_FORM_SPEED;
        const rate = paused ? 6 : 1.6;
        velocity += (target - velocity) * (1 - Math.exp(-dt * rate));
        position += velocity * dt;
      }
      render();
      raf = window.requestAnimationFrame(frame);
    };
    const start = () => {
      if (raf) return;
      last = 0;
      raf = window.requestAnimationFrame(frame);
    };
    const stop = () => {
      window.cancelAnimationFrame(raf);
      raf = 0;
      for (let i = 0; i < TOTAL; i++) setPlaying(i, false);
    };
    render();

    cleanups.push(observePreviewActivity(section, (active) => {
      inView = active;
      if (active) start();
      else stop();
    }));

    const onResize = () => {
      measure();
      render();
    };
    window.addEventListener('resize', onResize);
    cleanups.push(() => window.removeEventListener('resize', onResize));

    nudgeRef.current = (dir: number) => {
      nudgeTarget += dir;
      gsap.to(nudge, { v: nudgeTarget, duration: reduceMotion ? 0.01 : 0.68, ease: 'power3.inOut', overwrite: true });
    };
    cleanups.push(() => gsap.killTweensOf(nudge));

    const onDown = (e: PointerEvent) => {
      if (e.button !== 0) return;
      pointerId = e.pointerId;
      startX = lastX = e.clientX;
      startY = e.clientY;
      lastT = performance.now();
      dragVel = 0;
    };
    const onMove = (e: PointerEvent) => {
      if (pointerId !== e.pointerId) return;
      if (!dragging) {
        const dx = e.clientX - startX;
        if (Math.abs(dx) < DRAG_THRESHOLD || Math.abs(dx) < Math.abs(e.clientY - startY)) return;
        dragging = true;
        try {
          stage.setPointerCapture(e.pointerId);
        } catch {
          /* pointer already released */
        }
      }
      const now = performance.now();
      const dx = e.clientX - lastX;
      const dtMs = Math.max(1, now - lastT);
      const dPos = -dx / Math.max(1, stepX);
      position += dPos;
      dragVel = dragVel * 0.6 + (dPos / dtMs) * 1000 * 0.4;
      lastX = e.clientX;
      lastT = now;
    };
    const onUp = (e: PointerEvent) => {
      if (pointerId !== e.pointerId) return;
      pointerId = null;
      if (!dragging) return;
      dragging = false;
      const fresh = performance.now() - lastT < 90;
      velocity = fresh ? Math.max(-MAX_FLING, Math.min(MAX_FLING, dragVel)) : 0;
      suppressClickRef.current = true;
      window.setTimeout(() => {
        suppressClickRef.current = false;
      }, 60);
    };
    stage.addEventListener('pointerdown', onDown);
    stage.addEventListener('pointermove', onMove);
    stage.addEventListener('pointerup', onUp);
    stage.addEventListener('pointercancel', onUp);
    cleanups.push(() => {
      stage.removeEventListener('pointerdown', onDown);
      stage.removeEventListener('pointermove', onMove);
      stage.removeEventListener('pointerup', onUp);
      stage.removeEventListener('pointercancel', onUp);
    });

    // Keyboard arrows while the section is in view (and the viewer is closed).
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      if (pausedRef.current || document.body.classList.contains('gd-lightbox-open')) return;
      const tag = document.activeElement?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      const rect = section.getBoundingClientRect();
      const inView = rect.top < window.innerHeight * 0.85 && rect.bottom > window.innerHeight * 0.15;
      if (!inView && !section.contains(document.activeElement)) return;
      e.preventDefault();
      nudgeRef.current(e.key === 'ArrowRight' ? 1 : -1);
    };
    window.addEventListener('keydown', onKey);
    cleanups.push(() => window.removeEventListener('keydown', onKey));

    return () => cleanups.forEach((fn) => fn());
  }, []);

  const openAt = useCallback((idx: number, trigger: HTMLDivElement) => {
    if (suppressClickRef.current) return;
    window.clearTimeout(closeTimerRef.current);
    lastTriggerRef.current = trigger;
    pausedRef.current = true;
    setClosing(false);
    setOpenIndex(idx);
  }, []);

  const close = useCallback(() => {
    setClosing(true);
    window.clearTimeout(closeTimerRef.current);
    closeTimerRef.current = window.setTimeout(() => {
      setOpenIndex(null);
      setClosing(false);
      pausedRef.current = false;
      lastTriggerRef.current?.focus({ preventScroll: true });
    }, CLOSE_MS);
  }, []);

  const step = useCallback((dir: number) => {
    setOpenIndex((prev) => (prev === null ? prev : wrapProjectIndex(prev + dir, TOTAL)));
  }, []);

  const isOpen = openIndex !== null;

  useEffect(() => {
    if (!isOpen) return;
    const body = document.body;
    const prevOverflow = body.style.overflow;
    body.style.overflow = 'hidden';
    body.classList.add('gd-lightbox-open');
    closeBtnRef.current?.focus({ preventScroll: true });
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
      else if (e.key === 'ArrowRight') step(1);
      else if (e.key === 'ArrowLeft') step(-1);
    };
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      body.style.overflow = prevOverflow;
      body.classList.remove('gd-lightbox-open');
    };
  }, [isOpen, close, step]);

  useEffect(() => () => window.clearTimeout(closeTimerRef.current), []);

  const current = openIndex !== null ? WORK_PROJECTS[openIndex] : null;
  const [currentPart, totalPart] = formatProjectCounter(activeProject, TOTAL).split(' / ');

  return (
    <section className="work-section" id="work" ref={sectionRef} aria-label="Selected work carousel">
      <div className="wrap">
        <div className="sec-head reveal">
          <h2>Selected work built to hold attention.</h2>
          <p>
            A handful of the stories we&apos;ve shaped — from product launches to brand films. Every frame is
            built for retention first, beauty second, and beauty is never sacrificed.
          </p>
        </div>
      </div>

      <div className="work-category-head">
        <div ref={titleRef} className="work-category-title" aria-live="polite">
          {WORK_PROJECTS[activeProject]?.categoryLabel}
        </div>
      </div>

      <div className="work-carousel-stage" ref={stageRef}>
        {WORK_PROJECTS.map((project, idx) => {
          const slot = getRelativeCarouselSlot(idx, activeProject, TOTAL);
          const isActive = slot === 0;
          const isSidePreview = slot === -1 || slot === 1;
          return (
            <div
              key={project.id}
              ref={(el) => {
                cardRefs.current[idx] = el;
              }}
              className={`work-frame${isActive ? ' is-active' : ''}${isSidePreview ? ' is-preview' : ''}`}
              data-magnetic-big
              role="button"
              tabIndex={isActive ? 0 : -1}
              aria-label={`Play ${project.categoryLabel.toLowerCase()} video`}
              aria-hidden={!isActive && !isSidePreview}
              onClick={(e) => openAt(idx, e.currentTarget)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  openAt(idx, e.currentTarget);
                }
              }}
            >
              <video
                ref={(el) => {
                  videoRefs.current[idx] = el;
                }}
                className="work-video"
                data-src={media.resolve(project.videoSrc)}
                poster={media.isReplaced(project.videoSrc) ? undefined : media.resolve(project.posterSrc)}
                muted
                loop
                playsInline
                preload="none"
              />
              <div className="grain-inner" />
            </div>
          );
        })}
      </div>

      <div className="work-nav">
        <button
          type="button"
          className="carousel-btn"
          aria-label="Previous project"
          data-magnetic
          onClick={() => nudgeRef.current(-1)}
        >
          ←
        </button>
        <div className="carousel-counter" aria-live="polite">
          <span>{currentPart}</span>
          <span className="carousel-counter-total">{` / ${totalPart}`}</span>
        </div>
        <button
          type="button"
          className="carousel-btn"
          aria-label="Next project"
          data-magnetic
          onClick={() => nudgeRef.current(1)}
        >
          →
        </button>
      </div>

      {current &&
        openIndex !== null &&
        createPortal(
          <div
            className={`gd-lightbox${closing ? ' is-closing' : ''}`}
            role="dialog"
            aria-modal="true"
            aria-label={`${current.categoryLabel} video`}
            onClick={(e) => {
              if (swipedRef.current) {
                swipedRef.current = false;
                return;
              }
              if (e.target === e.currentTarget || (e.target as HTMLElement).classList.contains('gd-lb-stage')) {
                close();
              }
            }}
            onPointerDown={(e) => {
              swipeStartRef.current = { x: e.clientX, y: e.clientY };
            }}
            onPointerUp={(e) => {
              const start = swipeStartRef.current;
              swipeStartRef.current = null;
              if (!start || e.pointerType === 'mouse') return;
              if ((e.target as HTMLElement).tagName === 'VIDEO') return;
              const dir = getSwipeStep(e.clientX - start.x, e.clientY - start.y);
              if (dir !== 0) {
                swipedRef.current = true;
                step(dir);
              }
            }}
          >
            <div className="gd-lb-top">
              <span className="gd-lb-count">{formatProjectCounter(openIndex, TOTAL)}</span>
              <UploadSlotButton slot={slotOf(current.videoSrc)} accept="video/*" />
              <button
                ref={closeBtnRef}
                type="button"
                className="gd-lb-btn gd-lb-close"
                aria-label="Close video"
                onClick={close}
              >
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
                  <path d="M4 4L14 14M14 4L4 14" stroke="currentColor" strokeWidth="1.6" />
                </svg>
              </button>
            </div>

            <div className="gd-lb-stage">
              <figure className="gd-lb-figure" key={current.id}>
                <video
                  className="sf-lb-video"
                  src={media.resolve(current.videoSrc)}
                  poster={media.isReplaced(current.videoSrc) ? undefined : media.resolve(current.posterSrc)}
                  controls
                  autoPlay
                  loop
                  playsInline
                />
                <figcaption className="gd-lb-caption">{current.categoryLabel}</figcaption>
              </figure>
            </div>

            <button
              type="button"
              className="gd-lb-btn gd-lb-nav gd-lb-prev"
              aria-label="Previous video"
              onClick={() => step(-1)}
            >
              ←
            </button>
            <button
              type="button"
              className="gd-lb-btn gd-lb-nav gd-lb-next"
              aria-label="Next video"
              onClick={() => step(1)}
            >
              →
            </button>
          </div>,
          document.body,
        )}
    </section>
  );
}
