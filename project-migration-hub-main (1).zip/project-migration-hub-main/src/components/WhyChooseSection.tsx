import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { getNoteConnectorPath, type NoteBox } from '@/lib/motionHelpers';

const REASONS = [
  {
    title: 'Retention-first cuts',
    body: 'Every edit is paced against the scroll — built to hold attention in the first three seconds and every one after.',
    tone: 'sage',
  },
  {
    title: 'Senior eyes only',
    body: 'No trainee handoffs. A senior editor owns your project from brief to final export.',
    tone: 'peach',
  },
  {
    title: 'Built for scale',
    body: 'Templates and motion systems designed once, reused cleanly across every future asset.',
    tone: 'mint',
  },
  {
    title: 'Fast, honest turnaround',
    body: 'Clear timelines, async reviews, and delivery dates we actually hit.',
    tone: 'linen',
  },
] as const;

/** Resting tilt per note (deg), alternating like hand-pinned paper. */
const TILTS = [-2.4, 2, -1.6, 2.6];
/** Pointer-parallax depth per note (px at the board edge). */
const DEPTHS = [7, 11, 9, 6];

/**
 * WHY BRANDS CHOOSE XO.MOTION — four pinned paper notes in a vertical zigzag,
 * joined by a dotted line that draws itself on scroll. Notes and pins reveal
 * once; on desktop the board gets a faint pointer parallax (never idle motion).
 */
export default function WhyChooseSection() {
  const boardRef = useRef<HTMLDivElement | null>(null);
  const noteRefs = useRef<Array<HTMLLIElement | null>>([]);
  const floatRefs = useRef<Array<HTMLDivElement | null>>([]);
  const paperRefs = useRef<Array<HTMLDivElement | null>>([]);
  const pinRefs = useRef<Array<HTMLSpanElement | null>>([]);
  const drawRef = useRef<SVGPathElement | null>(null);
  const [path, setPath] = useState('');
  const [size, setSize] = useState({ w: 0, h: 0 });

  // measure the notes' layout boxes (untransformed) to route the connector
  useEffect(() => {
    const board = boardRef.current;
    if (!board) return;
    const measure = () => {
      const boxes: NoteBox[] = noteRefs.current
        .filter((n): n is HTMLLIElement => !!n)
        .map((n) => ({ left: n.offsetLeft, top: n.offsetTop, width: n.offsetWidth, height: n.offsetHeight }));
      setPath(getNoteConnectorPath(boxes));
      setSize({ w: board.offsetWidth, h: board.offsetHeight });
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(board);
    return () => ro.disconnect();
  }, []);

  // keep the draw-on stroke length in sync with the routed path
  useEffect(() => {
    const draw = drawRef.current;
    if (!draw || !path) return;
    const len = Math.ceil(draw.getTotalLength());
    draw.style.strokeDasharray = `${len}`;
    if (!draw.dataset['drawn']) draw.style.strokeDashoffset = `${len}`;
    draw.dataset['len'] = String(len);
    ScrollTrigger.refresh();
  }, [path]);

  useEffect(() => {
    const board = boardRef.current;
    if (!board) return;
    gsap.registerPlugin(ScrollTrigger);
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const draw = drawRef.current;

    if (reduceMotion) {
      if (draw) {
        draw.dataset['drawn'] = '1';
        draw.style.strokeDashoffset = '0';
      }
      return;
    }

    const ctx = gsap.context(() => {
      paperRefs.current.forEach((paper, i) => {
        if (!paper) return;
        const fromLeft = i % 2 === 0;
        const tl = gsap.timeline({
          // play once, never reverse — but no `once: true`: a once-trigger kills itself mid-refresh
          // when the page loads already scrolled past it, and ScrollTrigger then crashes
          // ("reading 'end'") while creating the connector's scrub trigger below.
          scrollTrigger: { trigger: paper, start: 'top 86%', toggleActions: 'play none none none' },
        });
        tl.fromTo(
          paper,
          { opacity: 0, x: fromLeft ? -46 : 46, y: 56, rotation: fromLeft ? -7 : 7, scale: 0.96 },
          { opacity: 1, x: 0, y: 0, rotation: 0, scale: 1, duration: 1.15, ease: 'power3.out' },
        );
        const pin = pinRefs.current[i];
        if (pin) {
          tl.fromTo(
            pin,
            { opacity: 0, scale: 0.2, y: -14 },
            { opacity: 1, scale: 1, y: 0, duration: 0.55, ease: 'back.out(2.4)' },
            0.55,
          );
        }
      });

      if (draw) {
        const len = () => Number(draw.dataset['len'] || draw.getTotalLength());
        gsap.fromTo(
          draw,
          { strokeDashoffset: () => len() },
          {
            strokeDashoffset: 0,
            ease: 'none',
            scrollTrigger: {
              trigger: board,
              start: 'top 72%',
              end: 'bottom 62%',
              scrub: 0.8,
              invalidateOnRefresh: true,
              onLeave: () => {
                draw.dataset['drawn'] = '1';
              },
            },
          },
        );
      }
    }, board);

    // faint pointer parallax for depth — desktop pointers only, eases back to rest
    const canHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const cleanups: Array<() => void> = [];
    if (canHover) {
      const setters = floatRefs.current.map((el) =>
        el
          ? {
              x: gsap.quickTo(el, 'x', { duration: 1.1, ease: 'power3.out' }),
              y: gsap.quickTo(el, 'y', { duration: 1.1, ease: 'power3.out' }),
            }
          : null,
      );
      const onMove = (e: PointerEvent) => {
        const r = board.getBoundingClientRect();
        const nx = ((e.clientX - r.left) / r.width - 0.5) * 2;
        const ny = ((e.clientY - r.top) / r.height - 0.5) * 2;
        setters.forEach((s, i) => {
          const depth = DEPTHS[i] ?? 8;
          s?.x(nx * depth);
          s?.y(ny * depth * 0.6);
        });
      };
      const onLeave = () => setters.forEach((s) => (s?.x(0), s?.y(0)));
      board.addEventListener('pointermove', onMove, { passive: true });
      board.addEventListener('pointerleave', onLeave, { passive: true });
      cleanups.push(() => {
        board.removeEventListener('pointermove', onMove);
        board.removeEventListener('pointerleave', onLeave);
      });
    }

    return () => {
      ctx.revert();
      cleanups.forEach((fn) => fn());
    };
  }, []);

  return (
    <section className="pad why-section" aria-labelledby="why-heading">
      <div className="wrap">
        <div className="sec-head reveal">
          <h2 id="why-heading">Why brands choose xo.motion.</h2>
          <p>Four reasons founders and creative leads keep coming back for their next launch.</p>
        </div>

        <div className="why-board" ref={boardRef}>
          <svg
            className="why-connector"
            width={size.w}
            height={size.h}
            viewBox={`0 0 ${size.w || 1} ${size.h || 1}`}
            aria-hidden="true"
            focusable="false"
          >
            <defs>
              <mask id="why-connector-draw" maskUnits="userSpaceOnUse" x="0" y="0" width={size.w} height={size.h}>
                <path ref={drawRef} d={path} fill="none" stroke="#fff" strokeWidth="8" strokeLinecap="round" />
              </mask>
            </defs>
            <path className="why-connector-line" d={path} mask="url(#why-connector-draw)" />
          </svg>

          <ol className="why-notes">
            {REASONS.map((reason, i) => (
              <li
                key={reason.title}
                className={`why-note why-note--${i % 2 === 0 ? 'left' : 'right'}`}
                style={{ ['--tilt' as string]: `${TILTS[i]}deg` }}
                ref={(el) => {
                  noteRefs.current[i] = el;
                }}
              >
                <div
                  className="why-float"
                  ref={(el) => {
                    floatRefs.current[i] = el;
                  }}
                >
                  <div
                    className="why-paper"
                    ref={(el) => {
                      paperRefs.current[i] = el;
                    }}
                  >
                    <span className="why-under" aria-hidden="true" />
                    <div className="why-sheet">
                      <div className={`why-inner why-inner--${reason.tone}`}>
                        <span className="why-num">{String(i + 1).padStart(2, '0')}</span>
                        <h3>{reason.title}</h3>
                        <p>{reason.body}</p>
                      </div>
                    </div>
                    <span
                      className={`why-pin why-pin--${i + 1}`}
                      aria-hidden="true"
                      ref={(el) => {
                        pinRefs.current[i] = el;
                      }}
                    >
                      <span className="why-pin-shadow" />
                      <span className="why-pin-base" />
                      <span className="why-pin-cap" />
                    </span>
                  </div>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
