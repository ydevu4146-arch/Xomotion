import { useEffect, useRef, useState, type ComponentType, type FormEvent, type KeyboardEvent } from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import { ArrowRight, Check, Loader2, X } from 'lucide-react';
import {
  ALL_PACKAGES,
  CUSTOM_PACKAGE,
  DEFAULT_MARKET,
  INQUIRY_SERVICES,
  MARKETS,
  MARKET_CURRENCY,
  MARKET_LABELS,
  PRICING_PACKAGES,
  getPackageById,
  inquirySchema,
  type Market,
  type PackageId,
} from '@/lib/pricing';
import { submitInquiry } from '@/lib/inquiry.functions';
import { CONTACT_EMAIL, buildInquiryMessage, openWhatsApp, whatsappUrl } from '@/lib/whatsapp';

type Service = (typeof INQUIRY_SERVICES)[number];

interface FormState {
  package: PackageId;
  country: Market;
  fullName: string;
  email: string;
  company: string;
  services: Service[];
  quantity: string;
  budget: string;
  timeline: string;
  details: string;
}

const emptyForm = (pkg: PackageId, country: Market): FormState => ({
  package: pkg,
  country,
  fullName: '',
  email: '',
  company: '',
  services: [],
  quantity: '',
  budget: '',
  timeline: '',
  details: '',
});

type Status = 'idle' | 'sending' | 'sent' | 'error';

const titleCase = (name: string) => name.charAt(0) + name.slice(1).toLowerCase();

function IndiaFlag() {
  return (
    <svg className="pk-flag" viewBox="0 0 24 16" aria-hidden="true">
      <rect width="24" height="16" fill="#ff9933" />
      <rect y="5.33" width="24" height="5.34" fill="#ffffff" />
      <rect y="10.67" width="24" height="5.33" fill="#138808" />
      <circle cx="12" cy="8" r="2.1" fill="none" stroke="#000080" strokeWidth="0.6" />
      <circle cx="12" cy="8" r="0.45" fill="#000080" />
    </svg>
  );
}

function UsaFlag() {
  const stripes = Array.from({ length: 7 }, (_, i) => i * 2);
  return (
    <svg className="pk-flag" viewBox="0 0 24 16" aria-hidden="true">
      <rect width="24" height="16" fill="#ffffff" />
      {stripes.map((s) => (
        <rect key={s} y={(s * 16) / 13} width="24" height={16 / 13} fill="#b22234" />
      ))}
      <rect width="10.4" height={(16 / 13) * 7} fill="#3c3b6e" />
      {[1.6, 4.2, 6.8].map((y) =>
        [1.5, 3.9, 6.3, 8.7].map((x) => (
          <circle key={`${x}-${y}`} cx={x} cy={y} r="0.55" fill="#ffffff" />
        )),
      )}
    </svg>
  );
}

const FLAGS: Record<Market, ComponentType> = { IN: IndiaFlag, US: UsaFlag };

function MarketToggle({
  value,
  onChange,
  size = 'lg',
  label,
}: {
  value: Market;
  onChange: (m: Market) => void;
  size?: 'lg' | 'sm';
  label: string;
}) {
  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) {
      e.preventDefault();
      const next = value === 'IN' ? 'US' : 'IN';
      onChange(next);
      (e.currentTarget.querySelector(`[data-market="${next}"]`) as HTMLElement | null)?.focus();
    }
  };
  return (
    <div
      className={`pk-toggle pk-toggle--${size}`}
      role="radiogroup"
      aria-label={label}
      data-active={value}
      onKeyDown={onKey}
    >
      <span className="pk-toggle-thumb" aria-hidden="true" />
      {MARKETS.map((m) => {
        const Flag = FLAGS[m];
        const on = value === m;
        return (
          <button
            key={m}
            type="button"
            role="radio"
            aria-checked={on}
            tabIndex={on ? 0 : -1}
            data-market={m}
            className={`pk-toggle-opt${on ? ' is-on' : ''}`}
            onClick={() => onChange(m)}
          >
            <Flag />
            <span>{MARKET_LABELS[m]}</span>
          </button>
        );
      })}
    </div>
  );
}

export default function PricingSection() {
  const gridRef = useRef<HTMLDivElement>(null);
  const [market, setMarket] = useState<Market>(DEFAULT_MARKET);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<FormState>(() => emptyForm('basic', DEFAULT_MARKET));
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [status, setStatus] = useState<Status>('idle');
  const [serverError, setServerError] = useState('');
  const [waUrl, setWaUrl] = useState('');

  // cards fade + slide up once the grid enters the viewport
  useEffect(() => {
    const grid = gridRef.current;
    if (!grid) return;
    if (!('IntersectionObserver' in window)) {
      grid.classList.add('is-in');
      return;
    }
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          grid.classList.add('is-in');
          obs.disconnect();
        }
      },
      { threshold: 0.12 },
    );
    obs.observe(grid);
    return () => obs.disconnect();
  }, []);

  const openInquiry = (pkg: PackageId) => {
    setForm((prev) =>
      status === 'sent' ? emptyForm(pkg, market) : { ...prev, package: pkg, country: market },
    );
    if (status !== 'sending') setStatus('idle');
    setErrors({});
    setServerError('');
    setOpen(true);
  };

  const update = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (errors[key]) setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const toggleService = (service: Service) => {
    update(
      'services',
      form.services.includes(service)
        ? form.services.filter((s) => s !== service)
        : [...form.services, service],
    );
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (status === 'sending') return;
    const parsed = inquirySchema.safeParse(form);
    if (!parsed.success) {
      const next: Partial<Record<keyof FormState, string>> = {};
      for (const issue of parsed.error.issues) {
        const key = issue.path[0] as keyof FormState;
        if (!next[key]) next[key] = issue.message;
      }
      setErrors(next);
      return;
    }
    setServerError('');
    // Open WhatsApp right away (inside the submit gesture so it isn't blocked),
    // with every filled-in detail pre-written in the chat.
    const url = whatsappUrl(buildInquiryMessage(parsed.data));
    setWaUrl(url);
    try {
      openWhatsApp(url);
    } catch {
      setStatus('error');
      setServerError(`WhatsApp could not be opened. Please try again, or email ${CONTACT_EMAIL}.`);
      return;
    }
    setStatus('sent');
    // Keep a copy of the inquiry in the database too; WhatsApp never waits on it.
    void submitInquiry({ data: parsed.data }).catch((err: unknown) => {
      console.error('Inquiry backup save failed', err);
    });
  };

  const selected = getPackageById(form.package);
  const isCustom = form.package === 'custom';
  const currencySymbol = form.country === 'US' ? '$' : '₹';

  return (
    <section className="pad pk-section" id="pricing">
      <div className="wrap">
        <div className="sec-head reveal">
          <div>
            <div className="eyebrow">Pricing &amp; Packages</div>
            <h2 style={{ marginTop: 18 }}>Creative packages. Built for your vision.</h2>
          </div>
          <p>
            From simple content edits to complete creative production, find the
            right package for your brand.
          </p>
        </div>

        <div className="pk-market">
          <MarketToggle value={market} onChange={setMarket} label="Show prices for" />
          <span className="pk-market-note" aria-live="polite">
            Prices shown in {MARKET_CURRENCY[market]}
          </span>
        </div>

        <div className="pk-grid" ref={gridRef}>
          {PRICING_PACKAGES.map((pkg, i) => (
            <article
              key={pkg.id}
              className={`pk-card pk-card--${pkg.id}${pkg.popular ? ' is-popular' : ''}`}
              style={{ ['--i' as string]: i }}
              aria-label={`${pkg.name} package`}
            >
              <div className="pk-glow" aria-hidden="true">
                <span className="pk-blob pk-blob--a" />
                <span className="pk-blob pk-blob--b" />
                <span className="pk-blob pk-blob--c" />
              </div>

              <div className="pk-top">
                <span className="pk-name">{pkg.name}</span>
                {pkg.popular && <span className="pk-badge">Most Popular</span>}
              </div>

              <div className="pk-head">
                <div className="pk-price">
                  {pkg.priceCaption && <span className="pk-caption">{pkg.priceCaption}</span>}
                  <span key={market} className="pk-amt" data-testid={`price-${pkg.id}`}>
                    {pkg.prices[market]}
                  </span>
                </div>
                <p className="pk-desc">{pkg.description}</p>
              </div>

              <div className="pk-cta-row">
                <button
                  type="button"
                  className="pk-cta"
                  onClick={() => openInquiry(pkg.id)}
                >
                  <span>{pkg.cta}</span>
                  <ArrowRight className="pk-cta-arrow" aria-hidden="true" />
                </button>
              </div>

              <div className="pk-list-wrap">
                <span className="pk-list-lbl">Deliverables</span>
                <ul className="pk-list">
                  {pkg.deliverables.map((d) => (
                    <li key={d}>
                      <span className="pk-check" aria-hidden="true">
                        <Check />
                      </span>
                      {d}
                    </li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>

        <div className="pk-custom reveal">
          <div className="pk-glow pk-card--custom" aria-hidden="true">
            <span className="pk-blob pk-blob--a" />
            <span className="pk-blob pk-blob--b" />
            <span className="pk-blob pk-blob--c" />
          </div>
          <div className="pk-custom-copy">
            <span className="pk-name">CUSTOM</span>
            <h3 className="pk-custom-title">{CUSTOM_PACKAGE.heading}</h3>
            <p className="pk-custom-desc">{CUSTOM_PACKAGE.description}</p>
          </div>
          <button
            type="button"
            className="pk-cta pk-cta--custom"
            onClick={() => openInquiry('custom')}
          >
            <span>{CUSTOM_PACKAGE.cta}</span>
            <ArrowRight className="pk-cta-arrow" aria-hidden="true" />
          </button>
        </div>
      </div>

      <Dialog.Root open={open} onOpenChange={setOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="pk-overlay" />
          <Dialog.Content
            className="pk-modal"
            aria-describedby={undefined}
            onOpenAutoFocus={(e) => {
              // keep phones from zooming straight into the first field
              if (window.matchMedia('(pointer: coarse)').matches) e.preventDefault();
            }}
          >
            <div className={`pk-modal-glow pk-card--${form.package}`} aria-hidden="true">
              <span className="pk-blob pk-blob--a" />
              <span className="pk-blob pk-blob--b" />
              <span className="pk-blob pk-blob--c" />
            </div>
            <Dialog.Close className="pk-modal-close" aria-label="Close">
              <X />
            </Dialog.Close>

            {status === 'sent' ? (
              <div className="pk-sent">
                <span className="pk-sent-icon" aria-hidden="true">
                  <Check />
                </span>
                <Dialog.Title className="pk-modal-title">Request received.</Dialog.Title>
                <p className="pk-modal-sub">
                  Thanks, {form.fullName.split(' ')[0]}. Your {selected.name.toLowerCase()}{' '}
                  inquiry is ready in WhatsApp — just tap send and the xo.motion team
                  will reply soon. WhatsApp didn&apos;t open?{' '}
                  <a href={waUrl} target="_blank" rel="noopener noreferrer">
                    <strong>Open WhatsApp</strong>
                  </a>
                  .
                </p>
                <Dialog.Close className="pk-cta pk-cta--inline">
                  <span>Close</span>
                </Dialog.Close>
              </div>
            ) : (
              <form className="pk-form" onSubmit={onSubmit} noValidate>
                <div className="eyebrow">{isCustom ? 'Custom pricing' : 'Project inquiry'}</div>
                <Dialog.Title className="pk-modal-title">
                  {isCustom
                    ? 'Tell us about your project.'
                    : `Let's start with ${titleCase(selected.name)}.`}
                </Dialog.Title>
                <p className="pk-modal-sub">
                  {isCustom
                    ? "Share your requirements, content volume and budget, and we'll build a package around them."
                    : `${selected.priceCaption} ${selected.prices[form.country]}. Share a few details and we'll get back to you.`}
                </p>

                <fieldset className="pk-field">
                  <legend className="pk-label">Package</legend>
                  <div className="pk-pills" role="radiogroup">
                    {ALL_PACKAGES.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        role="radio"
                        aria-checked={form.package === p.id}
                        className={`pk-pill${form.package === p.id ? ' is-on' : ''}`}
                        onClick={() => update('package', p.id)}
                      >
                        {titleCase(p.name)}
                      </button>
                    ))}
                  </div>
                </fieldset>

                <div className="pk-row">
                  <label className="pk-field">
                    <span className="pk-label">Name *</span>
                    <input
                      className="pk-input"
                      value={form.fullName}
                      onChange={(e) => update('fullName', e.target.value)}
                      autoComplete="name"
                      maxLength={100}
                      aria-invalid={!!errors.fullName}
                    />
                    {errors.fullName && <span className="pk-err">{errors.fullName}</span>}
                  </label>
                  <label className="pk-field">
                    <span className="pk-label">Email *</span>
                    <input
                      className="pk-input"
                      type="email"
                      value={form.email}
                      onChange={(e) => update('email', e.target.value)}
                      autoComplete="email"
                      maxLength={255}
                      aria-invalid={!!errors.email}
                    />
                    {errors.email && <span className="pk-err">{errors.email}</span>}
                  </label>
                </div>

                <div className="pk-field">
                  <span className="pk-label" id="pk-country-lbl">Country</span>
                  <MarketToggle
                    value={form.country}
                    onChange={(m) => update('country', m)}
                    size="sm"
                    label="Country"
                  />
                </div>

                {!isCustom && (
                  <label className="pk-field">
                    <span className="pk-label">Brand / Company Name</span>
                    <input
                      className="pk-input"
                      value={form.company}
                      onChange={(e) => update('company', e.target.value)}
                      autoComplete="organization"
                      maxLength={120}
                    />
                  </label>
                )}

                <fieldset className="pk-field">
                  <legend className="pk-label">Type of Service{isCustom ? ' *' : ''}</legend>
                  <div className="pk-pills">
                    {INQUIRY_SERVICES.map((s) => {
                      const on = form.services.includes(s);
                      return (
                        <button
                          key={s}
                          type="button"
                          aria-pressed={on}
                          className={`pk-pill${on ? ' is-on' : ''}`}
                          onClick={() => toggleService(s)}
                        >
                          {on && <Check className="pk-pill-check" aria-hidden="true" />}
                          {s}
                        </button>
                      );
                    })}
                  </div>
                  {errors.services && <span className="pk-err">{errors.services}</span>}
                </fieldset>

                <div className={`pk-row${isCustom ? '' : ' pk-row--3'}`}>
                  <label className="pk-field">
                    <span className="pk-label">Number of videos or designs</span>
                    <input
                      className="pk-input"
                      inputMode="numeric"
                      value={form.quantity}
                      onChange={(e) => update('quantity', e.target.value)}
                      placeholder="e.g. 8"
                      maxLength={60}
                    />
                  </label>
                  <label className="pk-field">
                    <span className="pk-label">Estimated Budget ({MARKET_CURRENCY[form.country]})</span>
                    <span className="pk-input-wrap">
                      <span className="pk-prefix" aria-hidden="true">{currencySymbol}</span>
                      <input
                        className="pk-input pk-input--prefixed"
                        inputMode="numeric"
                        value={form.budget}
                        onChange={(e) => update('budget', e.target.value)}
                        maxLength={60}
                      />
                    </span>
                  </label>
                  {!isCustom && (
                    <label className="pk-field">
                      <span className="pk-label">Project Timeline</span>
                      <input
                        className="pk-input"
                        value={form.timeline}
                        onChange={(e) => update('timeline', e.target.value)}
                        placeholder="e.g. 2 weeks"
                        maxLength={120}
                      />
                    </label>
                  )}
                </div>

                <label className="pk-field">
                  <span className="pk-label">Project Requirements</span>
                  <textarea
                    className="pk-input pk-textarea"
                    value={form.details}
                    onChange={(e) => update('details', e.target.value)}
                    rows={4}
                    maxLength={2000}
                  />
                </label>

                {serverError && (
                  <p className="pk-err pk-err--server" role="alert">
                    {serverError}
                  </p>
                )}

                <button type="submit" className="pk-cta pk-submit" disabled={status === 'sending'}>
                  {status === 'sending' ? (
                    <>
                      <Loader2 className="pk-spin" aria-hidden="true" />
                      <span>Sending…</span>
                    </>
                  ) : (
                    <>
                      <span>{isCustom ? 'REQUEST MY CUSTOM QUOTE' : 'SEND MY INQUIRY'}</span>
                      <ArrowRight className="pk-cta-arrow" aria-hidden="true" />
                    </>
                  )}
                </button>
              </form>
            )}
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </section>
  );
}
