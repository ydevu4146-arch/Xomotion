import { useEffect, useRef } from 'react';
import { getMarqueeDuration } from '@/lib/motionHelpers';
import { TESTIMONIALS, type Testimonial } from '@/lib/testimonials';

const SPEED_PX_PER_S = 36;

function TestimonialCard({ t }: { t: Testimonial }) {
  return (
    <div className="test-card">
      <div className="test-top">
        <div className="stars">★★★★★</div>
        {t.demo ? <span className="test-demo">Sample</span> : null}
      </div>
      <p>{`"${t.quote}"`}</p>
      <div className="test-who">
        <div>
          <strong>{t.name}</strong>
          {t.role ? <span>{t.role}</span> : null}
        </div>
      </div>
    </div>
  );
}

export default function TestimonialsSection() {
  const trackRef = useRef<HTMLDivElement>(null);

  // Size the loop so it always drifts at the same slow pixel speed.
  useEffect(() => {
    const track = trackRef.current;
    const set = track?.firstElementChild as HTMLElement | null;
    if (!track || !set) return;
    const apply = () => {
      track.style.setProperty(
        '--test-duration',
        `${getMarqueeDuration(set.offsetWidth, SPEED_PX_PER_S)}s`,
      );
    };
    apply();
    const ro = new ResizeObserver(apply);
    ro.observe(set);
    return () => {
      ro.disconnect();
    };
  }, []);

  return (
    <section className="pad">
      <div className="wrap">
        <div className="sec-head reveal">
          <h2>What clients say after launch.</h2>
          <p>
            A few words from the founders and marketers we&apos;ve worked
            alongside.
          </p>
        </div>
        <div className="test-marquee reveal">
          <div ref={trackRef} className="test-track">
            {[0, 1].map((copy) => (
              <div className="test-set" key={copy} aria-hidden={copy === 1 || undefined}>
                {TESTIMONIALS.map((t, i) => (
                  <TestimonialCard t={t} key={i} />
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
