import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  computeMagneticOffset,
  computeTiltAngles,
  getYouTubeEmbedUrl,
  nextCounterValue,
  toggleFaqIndex,
  toggleMobileMenuState,
} from '@/lib/motionHelpers';
import { mediaUrl } from '@/lib/media';
import {
  CONTACT_EMAIL,
  CONTACT_MAILTO,
  LETS_TALK_URL,
  WHATSAPP_BASE_URL,
  WHATSAPP_DISPLAY,
} from '@/lib/whatsapp';
import GraphicDesignSection from '@/components/GraphicDesignSection';
import ShortFormSection from '@/components/ShortFormSection';
import LongFormSection from '@/components/LongFormSection';
import PricingSection from '@/components/PricingSection';
import WhyChooseSection from '@/components/WhyChooseSection';
import TestimonialsSection from '@/components/TestimonialsSection';

const FAQ_ITEMS = [
  {
    question: 'How fast can you start a project?',
    answer:
      'Most projects kick off within 2–3 business days of a signed brief. Rush starts are available on the Professional and Enterprise tiers.',
  },
  {
    question: 'Do you work with international clients?',
    answer:
      'Yes — the majority of our clients are based in the US and Europe. We work async across time zones with clear daily check-ins.',
  },
  {
    question: 'What footage or assets do I need to provide?',
    answer:
      "Raw footage, brand assets, and any existing brand guidelines. If you don't have footage yet, we can scope a stock or AI-generated visual package.",
  },
  {
    question: 'Can I cancel or pause a monthly plan?',
    answer:
      "Yes, monthly plans can be paused or cancelled with 14 days' notice — no long-term lock-in required.",
  },
  {
    question: 'Do you offer one-off projects, or only retainers?',
    answer:
      'Both. Brand films and single launches are scoped and quoted individually outside the monthly tiers above.',
  },
];

export default function XoMotionSite() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const faqAnswerRefs = useRef<(HTMLDivElement | null)[]>([]);
  useEffect(() => {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    gsap.registerPlugin(ScrollTrigger);
    if (reduceMotion) ScrollTrigger.config({ limitCallbacks: true });
    gsap.ticker.lagSmoothing(500, 33);

    // Expose gsap on window just like the original CDN script
    const win = window as unknown as {
      gsap?: typeof gsap;
      ScrollTrigger?: typeof ScrollTrigger;
    };
    win.gsap = gsap;
    win.ScrollTrigger = ScrollTrigger;

    const loader = document.getElementById('loader');
    const fill = document.getElementById('loaderFill');
    let p = 0;
    let doneTimeout: number | undefined;

    function playHeroReveal() {
      gsap.to('.hero h1 .line span', {
        y: 0,
        duration: 1.1,
        stagger: 0.12,
        ease: 'power4.out',
        delay: 0.1,
      });
      gsap.fromTo(
        '.hero-sub, .hero-actions',
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 1, stagger: 0.1, delay: 0.2 },
      );
    }

    let iv: number | undefined;
    if (reduceMotion) {
      if (fill) fill.style.width = '100%';
      loader?.classList.add('done');
      playHeroReveal();
    } else {
      iv = window.setInterval(() => {
        p += 22;
        if (p >= 100) {
          p = 100;
          window.clearInterval(iv);
          if (fill) fill.style.width = '100%';
          doneTimeout = window.setTimeout(() => {
            loader?.classList.add('done');
            playHeroReveal();
          }, 350);
        } else if (fill) {
          fill.style.width = `${p}%`;
        }
      }, 140);
    }

    // custom cursor
    const cursor = document.getElementById('cursor');
    const ring = document.getElementById('cursorRing');
    let mx = 0;
    let my = 0;
    let rx = 0;
    let ry = 0;
    let rafId = 0;
    const canUseCursor = !reduceMotion && window.matchMedia('(hover: hover) and (pointer: fine) and (min-width: 901px)').matches;

    const onMouseMove = (e: MouseEvent) => {
      mx = e.clientX;
      my = e.clientY;
      if (cursor) {
        cursor.style.transform = `translate3d(${mx}px,${my}px,0) translate(-50%,-50%)`;
      }
      if (!rafId && canUseCursor && !document.hidden) rafId = window.requestAnimationFrame(ringLoop);
    };
    if (canUseCursor) window.addEventListener('mousemove', onMouseMove);

    function ringLoop() {
      rx += (mx - rx) * 0.16;
      ry += (my - ry) * 0.16;
      if (ring) {
        ring.style.transform = `translate3d(${rx}px,${ry}px,0) translate(-50%,-50%)`;
      }
      if (!document.hidden && (Math.abs(mx - rx) > 0.1 || Math.abs(my - ry) > 0.1)) {
        rafId = window.requestAnimationFrame(ringLoop);
      } else rafId = 0;
    }

    const cleanupFns: Array<() => void> = [];

    document.querySelectorAll<HTMLElement>('[data-magnetic]').forEach((el) => {
      const onEnter = () => {
        ring?.classList.add('big');
        if (cursor) cursor.style.opacity = '0';
      };
      const onLeave = () => {
        ring?.classList.remove('big');
        if (cursor) cursor.style.opacity = '1';
        el.style.transform = 'translate(0,0)';
      };
      const onMove = (e: MouseEvent) => {
        const offset = computeMagneticOffset(
          e.clientX,
          e.clientY,
          el.getBoundingClientRect(),
        );
        el.style.transform = `translate(${offset.x}px, ${offset.y}px)`;
      };
      el.addEventListener('mouseenter', onEnter);
      el.addEventListener('mouseleave', onLeave);
      el.addEventListener('mousemove', onMove);
      cleanupFns.push(() => {
        el.removeEventListener('mouseenter', onEnter);
        el.removeEventListener('mouseleave', onLeave);
        el.removeEventListener('mousemove', onMove);
      });
    });

    document
      .querySelectorAll<HTMLElement>('[data-magnetic-big]')
      .forEach((el) => {
        const onEnter = () => {
          if (el.classList.contains('work-frame') && !el.classList.contains('is-active')) {
            return;
          }
          ring?.classList.add('big', 'play');
          if (cursor) cursor.style.opacity = '0';
        };
        const onLeave = () => {
          ring?.classList.remove('big', 'play');
          if (cursor) cursor.style.opacity = '1';
        };
        el.addEventListener('mouseenter', onEnter);
        el.addEventListener('mouseleave', onLeave);
        cleanupFns.push(() => {
          el.removeEventListener('mouseenter', onEnter);
          el.removeEventListener('mouseleave', onLeave);
        });
      });

    // tilt on work cards
    document.querySelectorAll<HTMLElement>('[data-tilt]').forEach((card) => {
      const onMove = (e: MouseEvent) => {
        const { rotateX, rotateY } = computeTiltAngles(
          e.clientX,
          e.clientY,
          card.getBoundingClientRect(),
        );
        card.style.transform = `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-4px)`;
      };
      const onLeave = () => {
        card.style.transform = 'perspective(800px) rotateX(0) rotateY(0)';
      };
      card.addEventListener('mousemove', onMove);
      card.addEventListener('mouseleave', onLeave);
      cleanupFns.push(() => {
        card.removeEventListener('mousemove', onMove);
        card.removeEventListener('mouseleave', onLeave);
      });
    });

    // header scroll state & parallax blobs
    const header = document.getElementById('siteHeader');
    const parallaxElements = [...document.querySelectorAll<HTMLElement>('[data-parallax]')];
    let scrollRaf = 0;
    const updateScroll = () => {
      scrollRaf = 0;
      header?.classList.toggle('scrolled', window.scrollY > 40);
      if (!reduceMotion) parallaxElements.forEach((el) => {
          const speed = parseFloat(el.dataset['parallax'] || '0');
          el.style.transform = `translateY(${window.scrollY * speed}px)`;
        });
    };
    const onScroll = () => {
      if (!scrollRaf) scrollRaf = window.requestAnimationFrame(updateScroll);
    };
    window.addEventListener('scroll', onScroll, { passive: true });

    // scroll reveals via GSAP ScrollTrigger
    const revealTweens: gsap.core.Tween[] = [];
    if (reduceMotion) {
      gsap.set('.reveal', { opacity: 1, y: 0 });
    } else {
      gsap.utils.toArray<HTMLElement>('.reveal').forEach((el) => {
        const tween = gsap.to(el, {
          opacity: 1,
          y: 0,
          duration: 0.9,
          ease: 'power3.out',
          scrollTrigger: { trigger: el, start: 'top 88%', toggleActions: 'play none none none' },
        });
        revealTweens.push(tween);
      });
    }

    // counters
    const counters = document.querySelectorAll<HTMLElement>('[data-count]');
    const counterIntervals: number[] = [];
    const counterObs = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement;
            const target = parseInt(el.dataset['count'] || '0', 10);
            let cur = 0;
            const t = window.setInterval(() => {
              const stepRes = nextCounterValue(cur, target);
              cur = stepRes.value;
              if (stepRes.done) {
                window.clearInterval(t);
              }
              el.textContent = String(cur);
            }, 20);
            counterIntervals.push(t);
            counterObs.unobserve(el);
          }
        });
      },
      { threshold: 0.5 },
    );
    counters.forEach((c) => counterObs.observe(c));

    return () => {
      if (iv !== undefined) window.clearInterval(iv);
      if (doneTimeout !== undefined) window.clearTimeout(doneTimeout);
      window.cancelAnimationFrame(rafId);
      window.cancelAnimationFrame(scrollRaf);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('scroll', onScroll);
      cleanupFns.forEach((fn) => fn());
      revealTweens.forEach((t) => {
        t.scrollTrigger?.kill();
        t.kill();
      });
      counterObs.disconnect();
      counterIntervals.forEach((t) => window.clearInterval(t));
    };
  }, []);

  const handleFaqToggle = (index: number) => {
    setOpenFaq((prev) => toggleFaqIndex(prev, index));
  };

  return (
    <>
      <div className="grain" />
      <div className="cursor" id="cursor" />
      <div className="cursor-ring" id="cursorRing" />

      <div id="loader">
        <div className="loader-mark">xo.motion</div>
        <div className="loader-bar">
          <span id="loaderFill" />
        </div>
      </div>

      <header id="siteHeader">
        <div className="wrap">
          <nav>
            <a href="#" className="logo">
              <span className="dot" />
              xo.motion
            </a>
            <ul className={`navlinks${mobileMenuOpen ? ' mobile-open' : ''}`}>
              <li>
                <a
                  href="#work"
                  data-magnetic
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Work
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  data-magnetic
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Services
                </a>
              </li>
              <li>
                <a
                  href="#process"
                  data-magnetic
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Process
                </a>
              </li>
              <li>
                <a
                  href="#pricing"
                  data-magnetic
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Pricing
                </a>
              </li>
              <li>
                <a
                  href="#faq"
                  data-magnetic
                  onClick={() => setMobileMenuOpen(false)}
                >
                  FAQ
                </a>
              </li>
            </ul>
            <div className="nav-cta">
              <a
                href={LETS_TALK_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-primary"
                data-magnetic
              >
                Let&apos;s Talk
              </a>
              <div
                className="burger"
                role="button"
                tabIndex={0}
                aria-label="Toggle navigation menu"
                aria-expanded={mobileMenuOpen}
                onClick={() =>
                  setMobileMenuOpen((prev) => toggleMobileMenuState(prev))
                }
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setMobileMenuOpen((prev) => toggleMobileMenuState(prev));
                  }
                }}
              >
                <span />
                <span />
                <span />
              </div>
            </div>
          </nav>
        </div>
      </header>

      <main>
        {/* HERO */}
        <section className="hero">
          <div className="blob-field">
            <div className="blob b1" data-parallax="0.15" />
            <div className="blob b2" data-parallax="0.25" />
            <div className="blob b3" data-parallax="0.1" />
          </div>
          <div className="wrap hero-inner">
            <h1>
              <span className="line">
                <span>We don&apos;t just edit</span>
              </span>
              <span className="line">
                <span>videos. We create</span>
              </span>
              <span className="line">
                <span>experiences.</span>
              </span>
            </h1>
            <p className="hero-sub">
              Premium motion graphics, cinematic edits and product videos for
              brands, SaaS and creators.
            </p>
            <div className="hero-actions">
              <a href="#work" className="btn btn-primary" data-magnetic>
                View Work →
              </a>
              <a
                href={LETS_TALK_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-ghost"
                data-magnetic
              >
                Let&apos;s Talk
              </a>
            </div>
          </div>
        </section>

        {/* MARQUEE */}
        <div className="marquee-wrap">
          <div className="marquee-track">
            <span>SaaS Platforms</span>
            <span>AI Startups</span>
            <span>Luxury Brands</span>
            <span>D2C Labels</span>
            <span>YouTube Creators</span>
            <span>Tech Companies</span>
            <span>Growth Agencies</span>
            <span>SaaS Platforms</span>
            <span>AI Startups</span>
            <span>Luxury Brands</span>
            <span>D2C Labels</span>
            <span>YouTube Creators</span>
            <span>Tech Companies</span>
            <span>Growth Agencies</span>
          </div>
        </div>

        {/* WORK */}
        <ShortFormSection />

        {/* LONG-FORM VIDEOS */}
        <LongFormSection />

        {/* GRAPHIC DESIGN */}
        <GraphicDesignSection />

        {/* SERVICES */}
        <section className="pad" id="services">
          <div className="wrap services-band">
            <div className="wrap" style={{ padding: 0 }}>
              <div className="sec-head reveal">
                <div>
                  <div className="eyebrow">What we do</div>
                  <h2 style={{ marginTop: 18 }}>
                    One studio, every format your brand needs to move.
                  </h2>
                </div>
                <p>
                  From a fifteen-second hook to a full brand film, we build the
                  visual language once and let it scale across every format you
                  ship.
                </p>
              </div>
              <div className="services-list">
                <div className="service-row" data-magnetic>
                  <div className="left">
                    <span className="num">01</span>
                    <h3>Motion Graphics</h3>
                  </div>
                  <span className="cat">Brand</span>
                  <div className="arrow-o">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path
                        d="M4 12L12 4M12 4H5M12 4V11"
                        stroke="white"
                        strokeWidth="1.4"
                      />
                    </svg>
                  </div>
                </div>
                <div className="service-row" data-magnetic>
                  <div className="left">
                    <span className="num">02</span>
                    <h3>Video Editing</h3>
                  </div>
                  <span className="cat">Post</span>
                  <div className="arrow-o">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path
                        d="M4 12L12 4M12 4H5M12 4V11"
                        stroke="white"
                        strokeWidth="1.4"
                      />
                    </svg>
                  </div>
                </div>
                <div className="service-row" data-magnetic>
                  <div className="left">
                    <span className="num">03</span>
                    <h3>YouTube Editing</h3>
                  </div>
                  <span className="cat">Creator</span>
                  <div className="arrow-o">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path
                        d="M4 12L12 4M12 4H5M12 4V11"
                        stroke="white"
                        strokeWidth="1.4"
                      />
                    </svg>
                  </div>
                </div>
                <div className="service-row" data-magnetic>
                  <div className="left">
                    <span className="num">04</span>
                    <h3>Commercial Ads</h3>
                  </div>
                  <span className="cat">Paid</span>
                  <div className="arrow-o">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path
                        d="M4 12L12 4M12 4H5M12 4V11"
                        stroke="white"
                        strokeWidth="1.4"
                      />
                    </svg>
                  </div>
                </div>
                <div className="service-row" data-magnetic>
                  <div className="left">
                    <span className="num">05</span>
                    <h3>Explainer Videos</h3>
                  </div>
                  <span className="cat">SaaS</span>
                  <div className="arrow-o">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path
                        d="M4 12L12 4M12 4H5M12 4V11"
                        stroke="white"
                        strokeWidth="1.4"
                      />
                    </svg>
                  </div>
                </div>
                <div className="service-row" data-magnetic>
                  <div className="left">
                    <span className="num">06</span>
                    <h3>Product Videos</h3>
                  </div>
                  <span className="cat">Launch</span>
                  <div className="arrow-o">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path
                        d="M4 12L12 4M12 4H5M12 4V11"
                        stroke="white"
                        strokeWidth="1.4"
                      />
                    </svg>
                  </div>
                </div>
                <div className="service-row" data-magnetic>
                  <div className="left">
                    <span className="num">07</span>
                    <h3>UI Animation</h3>
                  </div>
                  <span className="cat">Product</span>
                  <div className="arrow-o">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path
                        d="M4 12L12 4M12 4H5M12 4V11"
                        stroke="white"
                        strokeWidth="1.4"
                      />
                    </svg>
                  </div>
                </div>
                <div className="service-row" data-magnetic>
                  <div className="left">
                    <span className="num">08</span>
                    <h3>Logo Animation</h3>
                  </div>
                  <span className="cat">Brand</span>
                  <div className="arrow-o">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path
                        d="M4 12L12 4M12 4H5M12 4V11"
                        stroke="white"
                        strokeWidth="1.4"
                      />
                    </svg>
                  </div>
                </div>
                <div className="service-row" data-magnetic>
                  <div className="left">
                    <span className="num">09</span>
                    <h3>Brand Films</h3>
                  </div>
                  <span className="cat">Story</span>
                  <div className="arrow-o">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path
                        d="M4 12L12 4M12 4H5M12 4V11"
                        stroke="white"
                        strokeWidth="1.4"
                      />
                    </svg>
                  </div>
                </div>
                <div className="service-row" data-magnetic>
                  <div className="left">
                    <span className="num">10</span>
                    <h3>Podcast &amp; Social Editing</h3>
                  </div>
                  <span className="cat">Content</span>
                  <div className="arrow-o">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path
                        d="M4 12L12 4M12 4H5M12 4V11"
                        stroke="white"
                        strokeWidth="1.4"
                      />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* WHY */}
        <WhyChooseSection />

        {/* PROCESS */}
        <section className="pad" id="process">
          <div className="wrap">
            <div className="sec-head reveal">
              <h2>How a project moves through the studio.</h2>
              <p>
                A nine-step pipeline, refined across dozens of launches, that
                keeps every project on time and on brand.
              </p>
            </div>
            <div className="process-timeline">
              <div className="proc-step reveal">
                <div className="proc-num">01</div>
                <div>
                  <h3>Discovery</h3>
                  <p>
                    We learn your brand, audience, and the outcome this piece
                    needs to drive.
                  </p>
                </div>
              </div>
              <div className="proc-step reveal">
                <div className="proc-num">02</div>
                <div>
                  <h3>Research</h3>
                  <p>
                    Competitive and category research to find the visual
                    language no one else is using.
                  </p>
                </div>
              </div>
              <div className="proc-step reveal">
                <div className="proc-num">03</div>
                <div>
                  <h3>Script</h3>
                  <p>
                    A tight, retention-paced script built around your key
                    message.
                  </p>
                </div>
              </div>
              <div className="proc-step reveal">
                <div className="proc-num">04</div>
                <div>
                  <h3>Storyboard</h3>
                  <p>
                    Frame-by-frame visual plan so there are no surprises before
                    animation begins.
                  </p>
                </div>
              </div>
              <div className="proc-step reveal">
                <div className="proc-num">05</div>
                <div>
                  <h3>Design</h3>
                  <p>
                    Key frames, color, and type system locked before a single
                    second is animated.
                  </p>
                </div>
              </div>
              <div className="proc-step reveal">
                <div className="proc-num">06</div>
                <div>
                  <h3>Animation</h3>
                  <p>
                    Motion built on the approved system — fluid, intentional,
                    on-brand.
                  </p>
                </div>
              </div>
              <div className="proc-step reveal">
                <div className="proc-num">07</div>
                <div>
                  <h3>Editing</h3>
                  <p>
                    Pacing, sound design, and color grade brought together into
                    one cohesive cut.
                  </p>
                </div>
              </div>
              <div className="proc-step reveal">
                <div className="proc-num">08</div>
                <div>
                  <h3>Revision</h3>
                  <p>Two structured rounds of feedback, folded in fast.</p>
                </div>
              </div>
              <div className="proc-step reveal">
                <div className="proc-num">09</div>
                <div>
                  <h3>Delivery</h3>
                  <p>
                    Every format and aspect ratio you need, ready to ship.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* STATS */}
        <section className="pad">
          <div className="wrap">
            <div className="stats-grid">
              <div className="stat reveal">
                <div className="num" data-count="180">
                  0
                </div>
                <div className="lbl">Projects delivered</div>
              </div>
              <div className="stat reveal">
                <div className="num" data-count="42">
                  0
                </div>
                <div className="lbl">Brands served worldwide</div>
              </div>
              <div className="stat reveal">
                <div className="num" data-count="96">
                  0
                </div>
                <div className="lbl">On-time delivery rate %</div>
              </div>
              <div className="stat reveal">
                <div className="num" data-count="4">
                  0
                </div>
                <div className="lbl">Years crafting motion</div>
              </div>
            </div>
          </div>
        </section>

        {/* TESTIMONIALS */}
        <TestimonialsSection />

        {/* PRICING */}
        <PricingSection />

        {/* FAQ */}
        <section className="pad" id="faq">
          <div className="wrap" style={{ maxWidth: 900 }}>
            <div className="sec-head faq-head reveal">
              <h2>Frequently asked questions.</h2>
            </div>
            <div className="faq-list">
              {FAQ_ITEMS.map((item, idx) => {
                const isOpen = openFaq === idx;
                const answerEl = faqAnswerRefs.current[idx];
                const maxHeight =
                  isOpen && answerEl ? `${answerEl.scrollHeight}px` : undefined;
                return (
                  <div
                    key={item.question}
                    className={`faq-item reveal${isOpen ? ' open' : ''}`}
                  >
                    <div
                      className="faq-q"
                      data-magnetic
                      role="button"
                      tabIndex={0}
                      aria-expanded={isOpen}
                      onClick={() => handleFaqToggle(idx)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          handleFaqToggle(idx);
                        }
                      }}
                    >
                      <h3>{item.question}</h3>
                      <div className="faq-plus" />
                    </div>
                    <div
                      className="faq-a"
                      ref={(el) => {
                        faqAnswerRefs.current[idx] = el;
                      }}
                      style={{ maxHeight }}
                    >
                      <p>{item.answer}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="pad" id="contact">
          <div className="wrap">
            <div className="cta-band reveal">
              <div
                className="eyebrow"
                style={{
                  justifyContent: 'center',
                  color: 'var(--ink-deep)',
                }}
              >
                Let&apos;s build something worth watching
              </div>
              <h2 style={{ marginTop: 22 }}>
                Have a launch coming up? Let&apos;s make it unforgettable.
              </h2>
              <a
                href={LETS_TALK_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-primary"
                data-magnetic
              >
                Let&apos;s Talk →
              </a>
              <div className="cta-contacts">
                <a href={WHATSAPP_BASE_URL} target="_blank" rel="noopener noreferrer">
                  WhatsApp: {WHATSAPP_DISPLAY}
                </a>
                <a href={CONTACT_MAILTO}>Email: {CONTACT_EMAIL}</a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer>
        <div className="wrap">
          <div className="foot-top">
            <div className="foot-brand">
              <a href="#" className="logo">
                <span className="dot" />
                xo.motion
              </a>
              <p>
                A boutique motion design studio helping ambitious brands tell
                stories worth stopping the scroll for.
              </p>
              <div className="foot-news">
                <input
                  type="email"
                  placeholder="Your email"
                  aria-label="Your email"
                />
                <button type="button" data-magnetic>
                  Subscribe →
                </button>
              </div>
            </div>
            <div className="foot-col">
              <h4>Studio</h4>
              <a href="#work">Work</a>
              <a href="#services">Services</a>
              <a href="#pricing">Pricing</a>
              <a href="#contact">Contact</a>
            </div>
            <div className="foot-col">
              <h4>WhatsApp</h4>
              <a href={WHATSAPP_BASE_URL} target="_blank" rel="noopener noreferrer">
                {WHATSAPP_DISPLAY}
              </a>
            </div>
            <div className="foot-col">
              <h4>Studio Email</h4>
              <a href={CONTACT_MAILTO}>{CONTACT_EMAIL}</a>
            </div>
          </div>
          <div className="foot-bottom">
            <span>© 2026 xo.motion. All rights reserved.</span>
            <div className="foot-legal">
              <a href="#">Privacy Policy</a>
              <a href="#">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}
