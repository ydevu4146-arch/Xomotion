import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import gsap from 'gsap';
import {
  getShowcaseMetrics,
  getShowcasePose,
  getShowcaseSlotCount,
  getShowcaseSlotX,
  getSwipeStep,
  wrapProjectIndex,
  type ShowcaseMetrics,
} from '@/lib/motionHelpers';
import { mediaUrl } from '@/lib/media';
import { useMediaOverrides, slotOf } from '@/lib/media-overrides';
import { UploadSlotButton } from '@/components/UploadSlotButton';
import { observePreviewActivity } from '@/lib/preview-performance';

/*
 * GRAPHIC DESIGN infinite showcase. To replace a design, swap the image file
 * behind its `file` name (src/assets/media/<file>.asset.json). Order = order in
 * the stream.
 */
interface GraphicDesignItem {
  id: string;
  category: string;
  file: string;
  width: number;
  height: number;
  focus?: string;
}

const GRAPHIC_DESIGNS: GraphicDesignItem[] = [
  { id: 'social-media', category: 'Social Media Designs', file: 'design-social-media.jpg', width: 1280, height: 1152 },
  { id: 'brand-identity', category: 'Brand Identity', file: 'design-brand-identity.jpg', width: 1536, height: 768 },
  { id: 'marketing-creatives', category: 'Marketing Creatives', file: 'design-marketing-creative.jpg', width: 1024, height: 1024, focus: '60% 35%' },
  { id: 'youtube-thumbnails', category: 'YouTube Thumbnails', file: 'design-youtube-thumbnail.jpg', width: 1536, height: 864, focus: '50% 30%' },
  { id: 'product-ads', category: 'Product Advertisements', file: 'design-product-ad.jpg', width: 768, height: 1344 },
  { id: 'promo-posters', category: 'Promotional Posters', file: 'design-promo-poster.jpg', width: 768, height: 1344 },
  { id: 'instagram-carousels', category: 'Instagram Carousels', file: 'design-instagram-carousel.jpg', width: 1536, height: 768 },
  { id: 'ecommerce', category: 'E-commerce Graphics', file: 'design-ecommerce.jpg', width: 1024, height: 1024 },
];

const TOTAL = GRAPHIC_DESIGNS.length;
const CLOSE_MS = 320;
/** Pointer travel (px) before a press becomes a drag instead of a click. */
const DRAG_THRESHOLD = 6;
const MAX_FLING = 2400;

function pad2(n: number) {
  return String(n).padStart(2, '0');
}

export default function GraphicDesignSection() {
  const media = useMediaOverrides();
  const sectionRef = useRef<HTMLElement | null>(null);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const cardRefs = useRef<Array<HTMLButtonElement | null>>([]);
  const [slotCount, setSlotCount] = useState(TOTAL * 2);
  const slotCountRef = useRef(slotCount);
  slotCountRef.current = slotCount;
  const pausedRef = useRef(false);
  const suppressClickRef = useRef(false);
  const nudgeRef = useRef<(dir: number) => void>(() => {});

  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [closing, setClosing] = useState(false);
  const lastTriggerRef = useRef<HTMLButtonElement | null>(null);
  const closeBtnRef = useRef<HTMLButtonElement | null>(null);
  const closeTimerRef = useRef<number | undefined>(undefined);
  const swipeStartRef = useRef<{ x: number; y: number } | null>(null);
  const swipedRef = useRef(false);

  // Endless right-to-left stream: one rAF loop writes transforms directly (no re-renders).
  useEffect(() => {
    const section = sectionRef.current;
    const stage = stageRef.current;
    if (!section || !stage) return;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const canHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const cleanups: Array<() => void> = [];

    let m: ShowcaseMetrics = getShowcaseMetrics(window.innerWidth);
    let half = stage.clientWidth / 2;
    let offset = 0;
    let velocity = reduceMotion ? 0 : m.speed;
    const nudge = { v: 0 };
    let nudgeTarget = 0;

    const measure = () => {
      m = getShowcaseMetrics(window.innerWidth);
      half = stage.clientWidth / 2;
      const st = stage.style;
      st.setProperty('--cw', `${m.cardW}px`);
      st.setProperty('--ch', `${m.cardH}px`);
      st.setProperty('--persp', `${m.perspective}px`);
      const next = getShowcaseSlotCount(stage.clientWidth, m.step, TOTAL);
      if (next !== slotCountRef.current) setSlotCount(next);
    };
    measure();

    const render = () => {
      const total = offset + nudge.v;
      const slots = slotCountRef.current;
      const cards = cardRefs.current;
      for (let j = 0; j < slots; j++) {
        const card = cards[j];
        if (!card) continue;
        const x = getShowcaseSlotX(j, m.step, total, slots);
        const p = getShowcasePose(x, half, m.maxRotate);
        const s = card.style;
        s.transform = `translate3d(${x.toFixed(2)}px,0,0) rotateY(${p.rotateY.toFixed(3)}deg) scale(${p.scale.toFixed(4)})`;
        s.opacity = p.opacity.toFixed(3);
        s.zIndex = String(p.zIndex);
      }
    };

    // Drag / swipe state
    let pointerId: number | null = null;
    let startX = 0;
    let startY = 0;
    let lastX = 0;
    let lastT = 0;
    let dragging = false;
    let dragVel = 0;

    let raf = 0;
    let last = 0;
    const frame = (now: number) => {
      const dt = last ? Math.min(0.05, (now - last) / 1000) : 0;
      last = now;
      if (!dragging) {
        const target = pausedRef.current || reduceMotion ? 0 : m.speed;
        const rate = pausedRef.current ? 6 : 1.6;
        velocity += (target - velocity) * (1 - Math.exp(-dt * rate));
        offset += velocity * dt;
      }
      render();
      raf = window.requestAnimationFrame(frame);
    };
    const start = () => {
      if (raf) return;
      last = 0;
      raf = window.requestAnimationFrame(frame);
    };
    const stop = () => {
      window.cancelAnimationFrame(raf);
      raf = 0;
    };

    // Only animate while the section is on screen.
    cleanups.push(observePreviewActivity(section, (active) => {
      if (active) start();
      else stop();
    }));

    const onResize = () => {
      measure();
      render();
    };
    window.addEventListener('resize', onResize);
    cleanups.push(() => window.removeEventListener('resize', onResize));
    render();

    nudgeRef.current = (dir: number) => {
      nudgeTarget += dir * m.step;
      gsap.to(nudge, { v: nudgeTarget, duration: reduceMotion ? 0.01 : 0.9, ease: 'power3.out', overwrite: true });
    };
    cleanups.push(() => gsap.killTweensOf(nudge));

    const onDown = (e: PointerEvent) => {
      if (e.button !== 0) return;
      pointerId = e.pointerId;
      startX = lastX = e.clientX;
      startY = e.clientY;
      lastT = performance.now();
      dragVel = 0;
    };
    const onMove = (e: PointerEvent) => {
      if (pointerId !== e.pointerId) return;
      if (!dragging) {
        const dx = e.clientX - startX;
        if (Math.abs(dx) < DRAG_THRESHOLD || Math.abs(dx) < Math.abs(e.clientY - startY)) return;
        dragging = true;
        stage.classList.add('is-dragging');
        try {
          stage.setPointerCapture(e.pointerId);
        } catch {
          /* pointer already released */
        }
      }
      const now = performance.now();
      const dx = e.clientX - lastX;
      const dtMs = Math.max(1, now - lastT);
      offset -= dx;
      dragVel = dragVel * 0.6 + (-dx / dtMs) * 1000 * 0.4;
      lastX = e.clientX;
      lastT = now;
    };
    const onUp = (e: PointerEvent) => {
      if (pointerId !== e.pointerId) return;
      pointerId = null;
      if (!dragging) return;
      dragging = false;
      stage.classList.remove('is-dragging');
      // Stale drag (finger held still) → no fling.
      const fresh = performance.now() - lastT < 90;
      velocity = fresh ? Math.max(-MAX_FLING, Math.min(MAX_FLING, dragVel)) : 0;
      suppressClickRef.current = true;
      window.setTimeout(() => {
        suppressClickRef.current = false;
      }, 60);
    };
    stage.addEventListener('pointerdown', onDown);
    stage.addEventListener('pointermove', onMove);
    stage.addEventListener('pointerup', onUp);
    stage.addEventListener('pointercancel', onUp);
    cleanups.push(() => {
      stage.removeEventListener('pointerdown', onDown);
      stage.removeEventListener('pointermove', onMove);
      stage.removeEventListener('pointerup', onUp);
      stage.removeEventListener('pointercancel', onUp);
    });

    if (canHover) {
      const ring = document.getElementById('cursorRing');
      const cursor = document.getElementById('cursor');
      const onOver = (e: PointerEvent) => {
        if (!(e.target as HTMLElement).closest('.gds-card')) return;
        ring?.classList.add('big');
        if (cursor) cursor.style.opacity = '0';
      };
      const onOut = (e: PointerEvent) => {
        const to = e.relatedTarget as HTMLElement | null;
        if (to?.closest?.('.gds-card')) return;
        ring?.classList.remove('big');
        if (cursor) cursor.style.opacity = '1';
      };
      stage.addEventListener('pointerover', onOver);
      stage.addEventListener('pointerout', onOut);
      cleanups.push(() => {
        stage.removeEventListener('pointerover', onOver);
        stage.removeEventListener('pointerout', onOut);
      });
    }

    return () => cleanups.forEach((fn) => fn());
  }, []);

  const openAt = useCallback((idx: number, trigger: HTMLButtonElement) => {
    if (suppressClickRef.current) return;
    window.clearTimeout(closeTimerRef.current);
    lastTriggerRef.current = trigger;
    pausedRef.current = true;
    setClosing(false);
    setOpenIndex(idx);
  }, []);

  const close = useCallback(() => {
    setClosing(true);
    window.clearTimeout(closeTimerRef.current);
    closeTimerRef.current = window.setTimeout(() => {
      setOpenIndex(null);
      setClosing(false);
      pausedRef.current = false;
      lastTriggerRef.current?.focus({ preventScroll: true });
    }, CLOSE_MS);
  }, []);

  const step = useCallback((dir: number) => {
    setOpenIndex((prev) => (prev === null ? prev : wrapProjectIndex(prev + dir, TOTAL)));
  }, []);

  const isOpen = openIndex !== null;

  // While open: keyboard controls, scroll lock, hide the custom cursor.
  useEffect(() => {
    if (!isOpen) return;
    const body = document.body;
    const prevOverflow = body.style.overflow;
    body.style.overflow = 'hidden';
    body.classList.add('gd-lightbox-open');
    closeBtnRef.current?.focus({ preventScroll: true });
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
      else if (e.key === 'ArrowRight') step(1);
      else if (e.key === 'ArrowLeft') step(-1);
    };
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      body.style.overflow = prevOverflow;
      body.classList.remove('gd-lightbox-open');
    };
  }, [isOpen, close, step]);

  useEffect(() => () => window.clearTimeout(closeTimerRef.current), []);

  const current = openIndex !== null ? GRAPHIC_DESIGNS[openIndex] : null;

  return (
    <section className="gds-section" id="graphic-design" aria-label="Graphic design" ref={sectionRef}>
      <div className="wrap gds-head">
        <h2 className="longform-heading gds-heading">GRAPHIC DESIGN</h2>
        <p className="gds-sub">Creative visuals. Distinctive identities. Lasting impressions.</p>
      </div>

      <div className="gds-stage" ref={stageRef}>
        <div className="gds-track">
          {Array.from({ length: slotCount }, (_, j) => {
            const idx = j % TOTAL;
            const item = GRAPHIC_DESIGNS[idx];
            if (!item) return null;
            const copy = j >= TOTAL;
            return (
              <button
                key={j}
                type="button"
                ref={(el) => {
                  cardRefs.current[j] = el;
                }}
                className="gds-card"
                aria-label={`Open ${item.category} preview`}
                aria-hidden={copy || undefined}
                tabIndex={copy ? -1 : undefined}
                onClick={(e) => openAt(idx, e.currentTarget)}
              >
                <span className="gds-card-inner">
                  <img
                    className="gds-img"
                    src={media.resolve(item.file)}
                    alt={`${item.category} design by xo.motion`}
                    width={item.width}
                    height={item.height}
                    loading="lazy"
                    decoding="async"
                    draggable={false}
                    style={item.focus ? { objectPosition: item.focus } : undefined}
                  />
                  <span className="gds-sheen" aria-hidden="true" />
                </span>
                <span className="gds-caption" aria-hidden="true">
                  <span className="gds-num">{pad2(idx + 1)}</span>
                  {item.category}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="gds-controls">
        <button type="button" className="gds-nav" aria-label="Previous designs" onClick={() => nudgeRef.current(-1)}>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path d="M13 8H3M3 8L7.5 3.5M3 8L7.5 12.5" stroke="currentColor" strokeWidth="1.5" />
          </svg>
        </button>
        <span className="gds-hint" aria-hidden="true">
          <span className="gds-hint-line" />
          Drag or tap to explore
          <span className="gds-hint-line" />
        </span>
        <button type="button" className="gds-nav" aria-label="Next designs" onClick={() => nudgeRef.current(1)}>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path d="M3 8H13M13 8L8.5 3.5M13 8L8.5 12.5" stroke="currentColor" strokeWidth="1.5" />
          </svg>
        </button>
      </div>

      {current &&
        openIndex !== null &&
        createPortal(
          <div
            className={`gd-lightbox${closing ? ' is-closing' : ''}`}
            role="dialog"
            aria-modal="true"
            aria-label={`${current.category} preview`}
            onClick={(e) => {
              if (swipedRef.current) {
                swipedRef.current = false;
                return;
              }
              if (e.target === e.currentTarget || (e.target as HTMLElement).classList.contains('gd-lb-stage')) {
                close();
              }
            }}
            onPointerDown={(e) => {
              swipeStartRef.current = { x: e.clientX, y: e.clientY };
            }}
            onPointerUp={(e) => {
              const start = swipeStartRef.current;
              swipeStartRef.current = null;
              if (!start || e.pointerType === 'mouse') return;
              const dir = getSwipeStep(e.clientX - start.x, e.clientY - start.y);
              if (dir !== 0) {
                swipedRef.current = true;
                step(dir);
              }
            }}
          >
            <div className="gd-lb-top">
              <span className="gd-lb-count">
                {pad2(openIndex + 1)} / {pad2(TOTAL)}
              </span>
              <UploadSlotButton slot={current.file} accept="image/*" />
              <button
                ref={closeBtnRef}
                type="button"
                className="gd-lb-btn gd-lb-close"
                aria-label="Close preview"
                onClick={close}
              >
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
                  <path d="M4 4L14 14M14 4L4 14" stroke="currentColor" strokeWidth="1.6" />
                </svg>
              </button>
            </div>

            <div className="gd-lb-stage">
              <figure className="gd-lb-figure" key={current.id}>
                <img
                  className="gd-lb-img"
                  src={media.resolve(current.file)}
                  alt={`${current.category} design by xo.motion`}
                  width={current.width}
                  height={current.height}
                  draggable={false}
                />
                <figcaption className="gd-lb-caption">{current.category}</figcaption>
              </figure>
            </div>

            <button
              type="button"
              className="gd-lb-btn gd-lb-nav gd-lb-prev"
              aria-label="Previous design"
              onClick={() => step(-1)}
            >
              ←
            </button>
            <button
              type="button"
              className="gd-lb-btn gd-lb-nav gd-lb-next"
              aria-label="Next design"
              onClick={() => step(1)}
            >
              →
            </button>
          </div>,
          document.body,
        )}
    </section>
  );
}
