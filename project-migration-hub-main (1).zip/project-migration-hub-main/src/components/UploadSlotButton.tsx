import { useRef, useState } from "react";
import { toast } from "sonner";
import { useIsAdmin } from "@/hooks/useIsAdmin";
import { uploadToSlot } from "@/lib/media-overrides";

/** Owner-only button that replaces the media in one portfolio card. */
export function UploadSlotButton({ slot, accept }: { slot: string; accept: string }) {
  const isAdmin = useIsAdmin();
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  if (!isAdmin) return null;
  return (
    <>
      <button
        type="button"
        className="gd-lb-btn upload-slot-btn"
        disabled={busy}
        onClick={(e) => {
          e.stopPropagation();
          input.current?.click();
        }}
      >
        {busy ? "Uploading…" : "⬆ Upload"}
      </button>
      <input
        ref={input}
        type="file"
        accept={accept}
        hidden
        onChange={async (e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (!file) return;
          setBusy(true);
          try {
            await uploadToSlot(slot, file);
            toast.success("Uploaded! Card updated.");
          } catch (err) {
            toast.error(err instanceof Error ? err.message : "Upload failed");
          } finally {
            setBusy(false);
          }
        }}
      />
    </>
  );
}
