import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import gsap from 'gsap';
import {
  LONG_FORM_FLOW_COPIES,
  LONG_FORM_FLOW_SPEED,
  computeTiltAngles,
  formatProjectCounter,
  getLongFormCrossingWipe,
  getLongFormFlowPhase,
  getLongFormFlowPose,
  getLongFormScrollPose,
  getSwipeStep,
  wrapProjectIndex,
} from '@/lib/motionHelpers';
import { mediaUrl } from '@/lib/media';
import { useMediaOverrides, slotOf } from '@/lib/media-overrides';
import { UploadSlotButton } from '@/components/UploadSlotButton';
import { observePreviewActivity, preparePreviewVideo } from '@/lib/preview-performance';

const LONG_FORM_VIDEOS = [
  {
    id: 'youtube-videos',
    categoryLabel: 'YouTube Videos',
    videoSrc: mediaUrl('long-1.mp4'),
    posterSrc: mediaUrl('long-thumb-1.jpg'),
  },
  {
    id: 'educational-videos',
    categoryLabel: 'Educational Videos',
    videoSrc: mediaUrl('long-2.mp4'),
    posterSrc: mediaUrl('long-thumb-2.jpg'),
  },
  {
    id: 'explainer-videos',
    categoryLabel: 'Explainer Videos',
    videoSrc: mediaUrl('long-3.mp4'),
    posterSrc: mediaUrl('long-thumb-3.jpg'),
  },
];

const VIDEO_COUNT = LONG_FORM_VIDEOS.length;
const CARDS = Array.from({ length: VIDEO_COUNT * LONG_FORM_FLOW_COPIES }, (_, i) => {
  const videoIndex = i % VIDEO_COUNT;
  const video = LONG_FORM_VIDEOS[videoIndex];
  return video
    ? { key: `${video.id}-${Math.floor(i / VIDEO_COUNT)}`, videoIndex, video }
    : null;
}).filter((card): card is NonNullable<typeof card> => card !== null);
const TOTAL = CARDS.length;
/** Card 1 (Educational) starts centred, matching the original stack. */
const START_OFFSET = 1;
const CLOSE_MS = 320;

interface CardMotion {
  tiltX: number;
  tiltY: number;
  press: number;
}

/**
 * LONG-FORM VIDEOS: the original overlapping three-card vertical stack, now
 * flowing endlessly bottom → top. One rAF loop owns a fractional `offset`;
 * two copies of the list wrap at an invisible far slot, and the front-card
 * hand-off is hidden by a short overlap wipe so the stack never jumps.
 */
export default function LongFormSection() {
  const media = useMediaOverrides();
  const sectionRef = useRef<HTMLElement | null>(null);
  const stackRef = useRef<HTMLDivElement | null>(null);
  const itemRefs = useRef<Array<HTMLDivElement | null>>([]);
  const cardRefs = useRef<Array<HTMLDivElement | null>>([]);
  const innerRefs = useRef<Array<HTMLDivElement | null>>([]);
  const videoRefs = useRef<Array<HTMLVideoElement | null>>([]);
  const shadeRefs = useRef<Array<HTMLDivElement | null>>([]);
  const topLabelRefs = useRef<Array<HTMLDivElement | null>>([]);
  const bottomLabelRefs = useRef<Array<HTMLDivElement | null>>([]);
  const pausedRef = useRef(false);

  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [closing, setClosing] = useState(false);
  const lastTriggerRef = useRef<HTMLDivElement | null>(null);
  const closeBtnRef = useRef<HTMLButtonElement | null>(null);
  const closeTimerRef = useRef<number | undefined>(undefined);
  const swipeStartRef = useRef<{ x: number; y: number } | null>(null);
  const swipedRef = useRef(false);

  useEffect(() => {
    const section = sectionRef.current;
    const stack = stackRef.current;
    if (!section || !stack) return;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const canHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const cleanups: Array<() => void> = [];

    let isMobile = window.innerWidth <= 768;
    let cardH = 495;
    let stepY = 282;
    const measure = () => {
      isMobile = window.innerWidth <= 768;
      const w = cardRefs.current[0]?.offsetWidth || (isMobile ? 391 : 880);
      cardH = w * (9 / 16);
      stepY = Math.round(cardH * 0.57);
      stack.style.height = `${Math.round(stepY * 2 + cardH * 0.91)}px`;
    };
    measure();

    const motions: CardMotion[] = CARDS.map(() => ({ tiltX: 0, tiltY: 0, press: 0 }));
    let offset = START_OFFSET;
    let velocity = reduceMotion ? 0 : LONG_FORM_FLOW_SPEED;
    let progress = reduceMotion ? 0.5 : 0;
    const scrollTarget = () => {
      if (reduceMotion) return 0.5;
      const rect = section.getBoundingClientRect();
      const vh = window.innerHeight || 1;
      return Math.min(1, Math.max(0, (vh - rect.top) / (vh + rect.height)));
    };
    let targetProgress = scrollTarget();
    progress = targetProgress;
    const onScroll = () => { targetProgress = scrollTarget(); };
    window.addEventListener('scroll', onScroll, { passive: true });
    cleanups.push(() => window.removeEventListener('scroll', onScroll));

    // write caches so unchanged strings are never re-applied
    const cache = CARDS.map(() => ({ shadow: '', mask: '', front: false, visible: true }));
    const phases = new Array<number>(TOTAL).fill(0);
    const wipes = new Array<number>(TOTAL).fill(0);

    // the front card's video plays on its own, exactly like the short-form carousel
    const playing = new Array<boolean>(TOTAL).fill(false);
    const playingSources = new Array<string | null>(TOTAL).fill(null);
    let inView = false;
    const setPlaying = (i: number, play: boolean) => {
      const video = videoRefs.current[i];
      if (!video) return;
      const source = video.dataset['src'] ?? null;
      if (inView && source) preparePreviewVideo(video, source);
      if (playingSources[i] !== source) {
        playingSources[i] = source;
        playing[i] = false;
      }
      if (playing[i] === play) return;
      playing[i] = play;
      if (play) {
        video.playbackRate = 1;
        video.play()?.catch(() => {
          playing[i] = false;
        });
      } else {
        video.pause();
      }
    };

    const render = () => {
      const poses = [];
      const scrollPoses = [];
      for (let i = 0; i < TOTAL; i++) {
        const phase = getLongFormFlowPhase(i, offset, TOTAL);
        phases[i] = phase;
        wipes[i] = getLongFormCrossingWipe(phase);
        poses.push(getLongFormFlowPose(phase, stepY));
        scrollPoses.push(getLongFormScrollPose(phase, progress, stepY, isMobile));
      }

      for (let i = 0; i < TOTAL; i++) {
        const item = itemRefs.current[i];
        const card = cardRefs.current[i];
        const inner = innerRefs.current[i];
        if (!item || !card || !inner) continue;
        const pose = poses[i];
        const sp = scrollPoses[i];
        const m = motions[i];
        const c = cache[i];
        if (!pose || !sp || !m || !c) continue;
        setPlaying(i, inView && !pausedRef.current && !reduceMotion && pose.isFront);

        item.style.transform = `translate3d(0,${pose.y.toFixed(2)}px,0) scale(${pose.scale.toFixed(4)})`;
        item.style.opacity = pose.opacity.toFixed(3);
        item.style.zIndex = String(pose.zIndex);

        const cardScale = sp.scale * (1 - 0.02 * m.press);
        card.style.transform =
          `perspective(1400px) translate3d(0,${sp.y.toFixed(2)}px,0) ` +
          `rotateX(${(sp.rotationX + m.tiltX).toFixed(3)}deg) rotateY(${m.tiltY.toFixed(3)}deg) scale(${cardScale.toFixed(4)})`;

        // soften both cards' shadows while they hand over the front position
        const prev = (i - 1 + TOTAL) % TOTAL;
        const shadowK = 1 - 0.8 * Math.max(wipes[i] ?? 0, wipes[prev] ?? 0);
        const shadow =
          `0 ${sp.shadowY.toFixed(1)}px ${sp.shadowBlur.toFixed(1)}px -20px rgba(63,74,65,${(sp.shadowAlpha * shadowK).toFixed(3)}), ` +
          `0 0 0 1px rgba(251,249,244,${(sp.ringAlpha * shadowK).toFixed(3)})`;
        if (shadow !== c.shadow) {
          card.style.boxShadow = shadow;
          c.shadow = shadow;
        }

        // overlap wipe: fade the upper card where the rising card lies beneath it
        let mask = 'none';
        const wipe = wipes[i] ?? 0;
        if (wipe > 0.001 && poses[(i + 1) % TOTAL] && scrollPoses[(i + 1) % TOTAL]) {
          const next = (i + 1) % TOTAL;
          const pb = poses[next];
          const sb = scrollPoses[next];
          if (!pb || !sb) continue;
          const sA = pose.scale * sp.scale;
          const sB = pb.scale * sb.scale;
          const bottomA = pose.y + pose.scale * sp.y + (cardH * sA) / 2;
          const topB = pb.y + pb.scale * sb.y - (cardH * sB) / 2;
          const overlapLocal = (bottomA - topB) / Math.max(0.01, sA);
          if (overlapLocal > 1) {
            // a soft edge rises from the upper card's bottom to the lower card's top,
            // so the rising card appears to slide over it before the order swaps
            const sweep = overlapLocal * wipe;
            const feather = 10;
            mask =
              `linear-gradient(to bottom, #000 calc(100% - ${sweep.toFixed(1)}px), ` +
              `transparent calc(100% - ${Math.max(0, sweep - feather).toFixed(1)}px))`;
          }
        }
        if (mask !== c.mask) {
          inner.style.maskImage = mask;
          inner.style.setProperty('-webkit-mask-image', mask);
          c.mask = mask;
        }

        const shade = shadeRefs.current[i];
        if (shade) shade.style.opacity = (1 - pose.brightness).toFixed(3);
        const top = topLabelRefs.current[i];
        if (top) top.style.opacity = pose.topLabelOpacity.toFixed(3);
        const bottom = bottomLabelRefs.current[i];
        if (bottom) bottom.style.opacity = pose.bottomLabelOpacity.toFixed(3);

        if (pose.isFront !== c.front) {
          c.front = pose.isFront;
          card.classList.toggle('is-active', pose.isFront);
          card.setAttribute('data-active', pose.isFront ? 'true' : 'false');
        }
        const visible = Math.abs(phases[i] ?? 0) < 1.35;
        if (visible !== c.visible) {
          c.visible = visible;
          card.style.pointerEvents = visible ? 'auto' : 'none';
          card.tabIndex = visible ? 0 : -1;
          card.setAttribute('aria-hidden', visible ? 'false' : 'true');
        }
      }
    };

    let raf = 0;
    let last = 0;
    const frame = (now: number) => {
      const dt = last ? Math.min(0.05, (now - last) / 1000) : 0;
      last = now;
      const paused = pausedRef.current;
      const target = paused || reduceMotion ? 0 : LONG_FORM_FLOW_SPEED;
      const rate = paused ? 6 : 1.4;
      velocity += (target - velocity) * (1 - Math.exp(-dt * rate));
      offset = (offset + velocity * dt) % TOTAL;
      progress += (targetProgress - progress) * (1 - Math.exp(-dt * 4));
      render();
      raf = window.requestAnimationFrame(frame);
    };
    const start = () => {
      if (raf || reduceMotion) return;
      last = 0;
      raf = window.requestAnimationFrame(frame);
    };
    const stop = () => {
      window.cancelAnimationFrame(raf);
      raf = 0;
      for (let i = 0; i < TOTAL; i++) setPlaying(i, false);
    };
    render();

    // only skip work while the section is well outside the viewport
    cleanups.push(observePreviewActivity(section, (active) => {
      inView = active;
      if (inView) {
        targetProgress = scrollTarget();
        render();
        start();
      } else stop();
    }));

    const onResize = () => {
      measure();
      targetProgress = scrollTarget();
      render();
    };
    window.addEventListener('resize', onResize);
    cleanups.push(() => window.removeEventListener('resize', onResize));

    // subtle hover tilt (desktop) and press feedback (touch); never pauses the flow
    if (!reduceMotion) {
      CARDS.forEach((_, idx) => {
        const card = cardRefs.current[idx];
        const m = motions[idx];
        if (!card || !m) return;
        const tween = (vars: gsap.TweenVars, duration: number) =>
          gsap.to(m, { ...vars, duration, ease: 'power3.out', overwrite: 'auto' });
        const onMove = (e: PointerEvent) => {
          if (!canHover || e.pointerType !== 'mouse') return;
          const { rotateX, rotateY } = computeTiltAngles(e.clientX, e.clientY, card.getBoundingClientRect());
          tween({ tiltX: rotateX * 0.6, tiltY: rotateY * 0.6 }, 0.6);
        };
        const onLeave = (e: PointerEvent) => {
          if (e.pointerType === 'mouse') tween({ tiltX: 0, tiltY: 0 }, 0.9);
        };
        const onDown = (e: PointerEvent) => {
          if (e.pointerType !== 'mouse') tween({ press: 1 }, 0.25);
        };
        const onUp = (e: PointerEvent) => {
          if (e.pointerType !== 'mouse') tween({ press: 0 }, 0.5);
        };
        card.addEventListener('pointermove', onMove, { passive: true });
        card.addEventListener('pointerleave', onLeave, { passive: true });
        card.addEventListener('pointerdown', onDown, { passive: true });
        card.addEventListener('pointerup', onUp, { passive: true });
        card.addEventListener('pointercancel', onUp, { passive: true });
        cleanups.push(() => {
          card.removeEventListener('pointermove', onMove);
          card.removeEventListener('pointerleave', onLeave);
          card.removeEventListener('pointerdown', onDown);
          card.removeEventListener('pointerup', onUp);
          card.removeEventListener('pointercancel', onUp);
          gsap.killTweensOf(m);
        });
      });
    }

    return () => cleanups.forEach((fn) => fn());
  }, []);

  const openAt = useCallback((videoIndex: number, trigger: HTMLDivElement) => {
    window.clearTimeout(closeTimerRef.current);
    lastTriggerRef.current = trigger;
    pausedRef.current = true;
    setClosing(false);
    setOpenIndex(videoIndex);
  }, []);

  const close = useCallback(() => {
    setClosing(true);
    window.clearTimeout(closeTimerRef.current);
    closeTimerRef.current = window.setTimeout(() => {
      setOpenIndex(null);
      setClosing(false);
      pausedRef.current = false;
      lastTriggerRef.current?.focus({ preventScroll: true });
    }, CLOSE_MS);
  }, []);

  const step = useCallback((dir: number) => {
    setOpenIndex((prev) => (prev === null ? prev : wrapProjectIndex(prev + dir, VIDEO_COUNT)));
  }, []);

  const isOpen = openIndex !== null;

  useEffect(() => {
    if (!isOpen) return;
    const body = document.body;
    const prevOverflow = body.style.overflow;
    body.style.overflow = 'hidden';
    body.classList.add('gd-lightbox-open');
    closeBtnRef.current?.focus({ preventScroll: true });
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
      else if (e.key === 'ArrowRight') step(1);
      else if (e.key === 'ArrowLeft') step(-1);
    };
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      body.style.overflow = prevOverflow;
      body.classList.remove('gd-lightbox-open');
    };
  }, [isOpen, close, step]);

  useEffect(() => () => window.clearTimeout(closeTimerRef.current), []);

  const current = openIndex !== null ? LONG_FORM_VIDEOS[openIndex] : null;

  return (
    <section className="longform-section" id="long-form" aria-label="Long-form videos" ref={sectionRef}>
      <div className="wrap">
        <h2 className="longform-heading reveal">LONG-FORM VIDEOS</h2>
        <div className="longform-stack" ref={stackRef}>
          <div className="longform-flow-window">
            {CARDS.map((card, idx) => (
              <div
                key={card.key}
                ref={(el) => {
                  itemRefs.current[idx] = el;
                }}
                className="longform-stack-item"
              >
                <div
                  ref={(el) => {
                    cardRefs.current[idx] = el;
                  }}
                  className="longform-card is-flow"
                  role="button"
                  tabIndex={0}
                  aria-label={`Play ${card.video.categoryLabel.toLowerCase()}`}
                  onClick={(e) => openAt(card.videoIndex, e.currentTarget)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      openAt(card.videoIndex, e.currentTarget);
                    }
                  }}
                >
                  <div
                    className="longform-card-inner"
                    ref={(el) => {
                      innerRefs.current[idx] = el;
                    }}
                  >
                    <div
                      ref={(el) => {
                        topLabelRefs.current[idx] = el;
                      }}
                      className="longform-label longform-label--top"
                    >
                      {card.video.categoryLabel}
                    </div>
                    <div
                      ref={(el) => {
                        bottomLabelRefs.current[idx] = el;
                      }}
                      className="longform-label longform-label--bottom"
                      aria-hidden="true"
                    >
                      {card.video.categoryLabel}
                    </div>
                    <video
                      className="longform-video"
                      ref={(el) => {
                        videoRefs.current[idx] = el;
                      }}
                      data-src={media.isReplaced(card.video.videoSrc) ? `${media.resolve(card.video.videoSrc)}#t=0.1` : card.video.videoSrc}
                      poster={media.isReplaced(card.video.videoSrc) ? undefined : card.video.posterSrc}
                      muted
                      loop
                      playsInline
                      preload="none"
                      tabIndex={-1}
                      aria-hidden="true"
                    />
                    <div
                      className="longform-card-shade"
                      ref={(el) => {
                        shadeRefs.current[idx] = el;
                      }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {current &&
        openIndex !== null &&
        createPortal(
          <div
            className={`gd-lightbox${closing ? ' is-closing' : ''}`}
            role="dialog"
            aria-modal="true"
            aria-label={`${current.categoryLabel} video`}
            onClick={(e) => {
              if (swipedRef.current) {
                swipedRef.current = false;
                return;
              }
              if (e.target === e.currentTarget || (e.target as HTMLElement).classList.contains('gd-lb-stage')) {
                close();
              }
            }}
            onPointerDown={(e) => {
              swipeStartRef.current = { x: e.clientX, y: e.clientY };
            }}
            onPointerUp={(e) => {
              const start = swipeStartRef.current;
              swipeStartRef.current = null;
              if (!start || e.pointerType === 'mouse') return;
              if ((e.target as HTMLElement).tagName === 'VIDEO') return;
              const dir = getSwipeStep(e.clientX - start.x, e.clientY - start.y);
              if (dir !== 0) {
                swipedRef.current = true;
                step(dir);
              }
            }}
          >
            <div className="gd-lb-top">
              <span className="gd-lb-count">{formatProjectCounter(openIndex, VIDEO_COUNT)}</span>
              <UploadSlotButton slot={slotOf(current.videoSrc)} accept="video/*" />
              <button
                ref={closeBtnRef}
                type="button"
                className="gd-lb-btn gd-lb-close"
                aria-label="Close video"
                onClick={close}
              >
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
                  <path d="M4 4L14 14M14 4L4 14" stroke="currentColor" strokeWidth="1.6" />
                </svg>
              </button>
            </div>

            <div className="gd-lb-stage">
              <figure className="gd-lb-figure" key={current.id}>
                <video
                  className="sf-lb-video lf-lb-video"
                  src={media.resolve(current.videoSrc)}
                  poster={media.isReplaced(current.videoSrc) ? undefined : media.resolve(current.posterSrc)}
                  controls
                  autoPlay
                  playsInline
                  loop
                />
                <figcaption className="gd-lb-caption">{current.categoryLabel}</figcaption>
              </figure>
            </div>

            <button
              type="button"
              className="gd-lb-btn gd-lb-nav gd-lb-prev"
              aria-label="Previous video"
              onClick={() => step(-1)}
            >
              ←
            </button>
            <button
              type="button"
              className="gd-lb-btn gd-lb-nav gd-lb-next"
              aria-label="Next video"
              onClick={() => step(1)}
            >
              →
            </button>
          </div>,
          document.body,
        )}
    </section>
  );
}
