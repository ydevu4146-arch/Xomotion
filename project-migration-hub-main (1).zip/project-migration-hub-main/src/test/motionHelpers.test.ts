import { test } from 'vitest';
import assert from 'node:assert/strict';
import {
  getMarqueeDuration,
  rampPlaybackRate,
  formatProjectCounter,
  getCarouselGap,
  getContinuousCarouselPose,
  getContinuousCarouselSlot,
  getFocusedCarouselIndex,
  shouldCarouselVideoPlay,
  getShowcaseMetrics,
  getShowcasePose,
  getShowcaseSlotCount,
  getShowcaseSlotX,
  getCarouselSlotPose,
  getLongFormLoopPose,
  getLongFormStackPose,
  getLongFormTransitionZIndex,
  getRelativeCarouselSlot,
  getYouTubeEmbedUrl,
  computeMagneticOffset,
  computeTiltAngles,
  nextCounterValue,
  toggleFaqIndex,
  toggleMobileMenuState,
  wrapLoopPhase,
  wrapProjectIndex,
} from '../lib/motionHelpers';

test('computeMagneticOffset calculates centered delta with 0.25/0.35 damping', () => {
  const rect = { left: 100, top: 200, width: 100, height: 40 };
  const center = computeMagneticOffset(150, 220, rect);
  assert.deepEqual(center, { x: 0, y: 0 });

  const offset = computeMagneticOffset(170, 230, rect);
  assert.deepEqual(offset, { x: 5, y: 3.5 });
});

test('computeTiltAngles maps cursor position inside card bounds to rotateX/rotateY', () => {
  const rect = { left: 0, top: 0, width: 400, height: 200 };
  assert.deepEqual(computeTiltAngles(200, 100, rect), { rotateX: 0, rotateY: 0 });
  assert.deepEqual(computeTiltAngles(400, 0, rect), { rotateX: 3, rotateY: 4 });
  assert.deepEqual(computeTiltAngles(0, 200, rect), { rotateX: -3, rotateY: -4 });
});

test('nextCounterValue increments smoothly and caps at target', () => {
  assert.deepEqual(nextCounterValue(0, 180), { value: 3, done: false });
  assert.deepEqual(nextCounterValue(178, 180), { value: 180, done: true });
  assert.deepEqual(nextCounterValue(0, 4), { value: 1, done: false });
  assert.deepEqual(nextCounterValue(3, 4), { value: 4, done: true });
});

test('toggleFaqIndex opens clicked item and collapses when clicked again', () => {
  assert.equal(toggleFaqIndex(null, 2), 2);
  assert.equal(toggleFaqIndex(2, 2), null);
  assert.equal(toggleFaqIndex(2, 0), 0);
});

test('toggleMobileMenuState toggles open/closed boolean', () => {
  assert.equal(toggleMobileMenuState(false), true);
  assert.equal(toggleMobileMenuState(true), false);
});

test('wrapProjectIndex wraps negative and overflowing indices cleanly', () => {
  assert.equal(wrapProjectIndex(0, 6), 0);
  assert.equal(wrapProjectIndex(6, 6), 0);
  assert.equal(wrapProjectIndex(-1, 6), 5);
  assert.equal(wrapProjectIndex(7, 6), 1);
});

test('getRelativeCarouselSlot maps 6 projects to continuous gallery slots', () => {
  assert.equal(getRelativeCarouselSlot(0, 0, 6), 0);
  assert.equal(getRelativeCarouselSlot(1, 0, 6), 1);
  assert.equal(getRelativeCarouselSlot(5, 0, 6), -1);
  assert.equal(getRelativeCarouselSlot(4, 0, 6), -2);
  assert.equal(getRelativeCarouselSlot(0, 5, 6), 1);
});

test('formatProjectCounter formats 1-based zero-padded counter string', () => {
  assert.equal(formatProjectCounter(0, 6), '01 / 06');
  assert.equal(formatProjectCounter(5, 6), '06 / 06');
  assert.equal(formatProjectCounter(-1, 6), '06 / 06');
});

test('getCarouselSlotPose centers sharp active frame, shows blurred tilted side previews, and hides far slots', () => {
  const active = getCarouselSlotPose(0, 304, 48, false);
  const left = getCarouselSlotPose(-1, 304, 48, false);
  const right = getCarouselSlotPose(1, 304, 48, false);
  const farLeft = getCarouselSlotPose(-2, 304, 48, false);
  const farRight = getCarouselSlotPose(2, 304, 48, false);

  assert.equal(active.x, 0);
  assert.equal(active.scale, 1);
  assert.equal(active.opacity, 1);
  assert.equal(active.rotateY, 0);
  assert.equal(active.blur, 0);
  assert.equal(active.brightness, 1);
  assert.ok(active.zIndex > right.zIndex);

  assert.equal(left.x, -right.x);
  assert.ok(left.opacity > 0.5 && right.opacity > 0.5);
  assert.equal(left.rotateY, -right.rotateY);
  assert.ok(left.rotateY > 0 && right.rotateY < 0);
  assert.ok(left.x < 0 && right.x > 0);
  assert.ok(left.scale < 1 && right.scale < 1);
  assert.ok(left.blur > 0 && right.blur > 0);
  assert.ok(left.brightness < 1 && right.brightness < 1);

  assert.equal(farLeft.opacity, 0);
  assert.equal(farRight.opacity, 0);
  assert.ok(farLeft.x < left.x && farRight.x > right.x);
  assert.ok(farLeft.zIndex < left.zIndex);
});

test('getLongFormStackPose elevates active card and tucks top/bottom cards symmetrically', () => {
  const top = getLongFormStackPose(0, 1);
  const center = getLongFormStackPose(1, 1);
  const bottom = getLongFormStackPose(2, 1);

  assert.equal(center.scale, 1);
  assert.equal(center.opacity, 1);
  assert.equal(center.brightness, 1);
  assert.equal(center.zIndex, 30);
  assert.equal(center.labelPosition, 'top');

  assert.equal(top.scale, bottom.scale);
  assert.ok(top.scale < center.scale);
  assert.ok(top.zIndex < center.zIndex);
  assert.equal(top.transformOrigin, 'center bottom');
  assert.equal(top.labelPosition, 'top');
  assert.equal(bottom.transformOrigin, 'center top');
  assert.equal(bottom.labelPosition, 'bottom');

  const far = getLongFormStackPose(2, 0);
  assert.ok(far.scale < getLongFormStackPose(1, 0).scale);
  assert.ok(far.zIndex < getLongFormStackPose(1, 0).zIndex);
});

test('getYouTubeEmbedUrl normalizes watch, short, embed, and raw IDs to nocookie embed URLs with enablejsapi', () => {
  assert.equal(
    getYouTubeEmbedUrl('dQw4w9WgXcQ'),
    'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0&modestbranding=1&enablejsapi=1',
  );
  assert.equal(
    getYouTubeEmbedUrl('https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=12s'),
    'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0&modestbranding=1&enablejsapi=1',
  );
  assert.equal(
    getYouTubeEmbedUrl('https://youtu.be/dQw4w9WgXcQ'),
    'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0&modestbranding=1&enablejsapi=1',
  );
  assert.equal(
    getYouTubeEmbedUrl('https://www.youtube.com/embed/dQw4w9WgXcQ'),
    'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0&modestbranding=1&enablejsapi=1',
  );
  assert.equal(getYouTubeEmbedUrl(''), null);
  assert.equal(getYouTubeEmbedUrl('not-a-valid-url'), null);
});

test('wrapLoopPhase wraps seamlessly within [-1.5, 1.5) for 3 cards', () => {
  assert.equal(wrapLoopPhase(-1), -1);
  assert.equal(wrapLoopPhase(0), 0);
  assert.equal(wrapLoopPhase(1), 1);
  assert.equal(wrapLoopPhase(1.5), -1.5);
  assert.equal(wrapLoopPhase(2), -1);
});

test('getLongFormLoopPose produces seamless depth, invisible wrap at ±1.5, and continuous top/bottom labels', () => {
  const top = getLongFormLoopPose(-1, 200);
  const center = getLongFormLoopPose(0, 200);
  const bottom = getLongFormLoopPose(1, 200);
  const wrapSeam = getLongFormLoopPose(1.5, 200);

  assert.equal(center.y, 0);
  assert.equal(center.scale, 1);
  assert.equal(center.opacity, 1);
  assert.equal(center.isFront, true);
  assert.equal(center.topLabelOpacity, 1);
  assert.equal(center.bottomLabelOpacity, 0);

  assert.equal(top.y, -200);
  assert.equal(bottom.y, 200);
  assert.equal(top.scale, bottom.scale);
  assert.ok(top.zIndex < center.zIndex && bottom.zIndex < center.zIndex);
  assert.equal(top.topLabelOpacity, 1);
  assert.equal(bottom.bottomLabelOpacity, 1);

  assert.equal(wrapSeam.opacity, 0);
  assert.ok(wrapSeam.zIndex < top.zIndex);
});

test('getLongFormTransitionZIndex places clicked front card on top and wrapping card behind stack', () => {
  assert.equal(getLongFormTransitionZIndex(-1, 0), 100);
  assert.equal(getLongFormTransitionZIndex(0, 1), 50);
  assert.equal(getLongFormTransitionZIndex(1, -1), 25);
  assert.equal(getLongFormTransitionZIndex(-1, 1), 25);
});

test('long-form scroll pose: stacked at entry, focused card scales to 1.05 once separated', async () => {
  const { getLongFormScrollPose } = await import('../lib/motionHelpers');
  const entryFront = getLongFormScrollPose(0, 0, 200);
  const entryBack = getLongFormScrollPose(-1, 0, 200);
  assert.equal(entryFront.scale, 1);
  assert.ok(entryBack.y > 0, 'card above is tucked down toward the front card');
  assert.ok(entryBack.scale < 1);

  const mid = getLongFormScrollPose(0, 0.5, 200);
  assert.ok(Math.abs(mid.scale - 1.05) < 1e-9);
  assert.equal(mid.y, 0);
  assert.equal(mid.rotationX, 0);
});

test('long-form scroll pose is reversible: same progress gives same pose', async () => {
  const { getLongFormScrollPose } = await import('../lib/motionHelpers');
  const down = getLongFormScrollPose(1, 0.3, 200);
  getLongFormScrollPose(1, 0.9, 200);
  const up = getLongFormScrollPose(1, 0.3, 200);
  assert.deepEqual(down, up);
  assert.deepEqual(getLongFormScrollPose(1, -2, 200), getLongFormScrollPose(1, 0, 200));
});

test('long-form background cards never exceed base scale', async () => {
  const { getLongFormScrollPose } = await import('../lib/motionHelpers');
  for (const p of [0, 0.25, 0.5, 0.75, 1]) {
    assert.ok(getLongFormScrollPose(1, p, 200).scale <= 1);
    assert.ok(getLongFormScrollPose(-1, p, 200).scale <= 1);
  }
});

test('graphic design parallax follows the cursor and is capped at the strength', async () => {
  const { computeParallaxOffset } = await import('../lib/motionHelpers');
  const rect = { left: 100, top: 100, width: 200, height: 100 };
  assert.deepEqual(computeParallaxOffset(200, 150, rect, 12), { x: 0, y: 0 });
  assert.deepEqual(computeParallaxOffset(300, 200, rect, 12), { x: 12, y: 12 });
  assert.deepEqual(computeParallaxOffset(100, 100, rect, 12), { x: -12, y: -12 });
  assert.deepEqual(computeParallaxOffset(9999, -9999, rect, 12), { x: 12, y: -12 });
  assert.deepEqual(computeParallaxOffset(5, 5, { left: 0, top: 0, width: 0, height: 0 }), { x: 0, y: 0 });
});

test('lightbox swipe: left goes next, right goes previous, small or vertical does nothing', async () => {
  const { getSwipeStep } = await import('../lib/motionHelpers');
  assert.equal(getSwipeStep(-80, 10), 1);
  assert.equal(getSwipeStep(80, 10), -1);
  assert.equal(getSwipeStep(-30, 0), 0);
  assert.equal(getSwipeStep(-80, 120), 0);
});

test('getCarouselGap keeps the mobile gap at 18px', () => {
  assert.equal(getCarouselGap(390), 18);
  assert.equal(getCarouselGap(768), 18);
});

test('getCarouselGap never goes below 48px on tablet/desktop', () => {
  assert.equal(getCarouselGap(800), 48);
  assert.equal(getCarouselGap(1280), 48);
});

test('getCarouselGap grows on large screens but caps at 72px', () => {
  assert.equal(getCarouselGap(1920), 67);
  assert.equal(getCarouselGap(3000), 72);
});

const SHOWCASE_WIDTHS = [360, 390, 768, 1024, 1280, 1920, 2560];

test('showcase: renders whole copies of all 8 projects, so the order never breaks', () => {
  for (const w of SHOWCASE_WIDTHS) {
    const m = getShowcaseMetrics(w);
    const slots = getShowcaseSlotCount(w, m.step, 8);
    assert.equal(slots % 8, 0, `${w}px`);
    assert.ok(slots >= 16, `${w}px`);
  }
});

test('showcase: the loop seam is always off-screen, so there is never a gap or visible jump', () => {
  for (const w of SHOWCASE_WIDTHS) {
    const m = getShowcaseMetrics(w);
    const slots = getShowcaseSlotCount(w, m.step, 8);
    const half = (slots * m.step) / 2;
    // A card wraps when its center crosses -half: it must be fully past the screen edge.
    assert.ok(half - m.cardW * 1.06 / 2 >= w / 2, `${w}px seam visible`);
  }
});

test('showcase: cards keep constant spacing and move right to left as the offset grows', () => {
  const step = 300;
  const slots = 16;
  const before = getShowcaseSlotX(5, step, 1000, slots);
  const after = getShowcaseSlotX(5, step, 1010, slots);
  assert.equal(after, before - 10);
  for (let s = 0; s < slots; s++) {
    const x = getShowcaseSlotX(s, step, 1234.5, slots);
    const xNext = getShowcaseSlotX(s + 1, step, 1234.5, slots);
    if (xNext > x) assert.ok(Math.abs(xNext - x - step) < 1e-6);
  }
});

test('showcase: one full loop of offset returns every card to the same place', () => {
  const step = 300;
  const slots = 16;
  for (let s = 0; s < slots; s++) {
    const a = getShowcaseSlotX(s, step, 777, slots);
    const b = getShowcaseSlotX(s, step, 777 + slots * step, slots);
    assert.ok(Math.abs(a - b) < 1e-6);
  }
});

test('showcase: center card is larger and flat, side cards curve inward symmetrically', () => {
  const center = getShowcasePose(0, 640, 24);
  const right = getShowcasePose(500, 640, 24);
  const left = getShowcasePose(-500, 640, 24);
  assert.equal(center.rotateY, 0);
  assert.ok(center.scale > 1);
  assert.ok(right.scale < center.scale);
  assert.ok(right.rotateY < 0 && left.rotateY > 0);
  assert.equal(right.rotateY, -left.rotateY);
  assert.ok(center.zIndex > right.zIndex);
  assert.equal(center.opacity, 1);
  assert.ok(getShowcasePose(900, 640, 24).opacity < 1);
});

test('short-form: videos travel right to left at a constant pace as the position grows', () => {
  const a = getContinuousCarouselPose(getContinuousCarouselSlot(1, 0.2, 6), 300, 48, false);
  const b = getContinuousCarouselPose(getContinuousCarouselSlot(1, 0.4, 6), 300, 48, false);
  const c = getContinuousCarouselPose(getContinuousCarouselSlot(1, 0.6, 6), 300, 48, false);
  assert.ok(b.x < a.x && c.x < b.x);
  assert.ok(Math.abs((a.x - b.x) - (b.x - c.x)) < 1e-6);
});

test('short-form: integer positions match the original carousel poses exactly', () => {
  for (const slot of [-1, 0, 1]) {
    const blended = getContinuousCarouselPose(slot, 304, 48, false);
    const fixed = getCarouselSlotPose(slot, 304, 48, false);
    assert.equal(blended.x, fixed.x);
    assert.equal(blended.scale, fixed.scale);
    assert.equal(blended.blur, fixed.blur);
  }
});

test('short-form: the loop wraps only where videos are invisible, so there is no visible jump', () => {
  // A card wraps from slot -3 to +3; both ends must be fully transparent.
  assert.equal(getContinuousCarouselPose(-2.999, 300, 48, false).opacity, 0);
  assert.equal(getContinuousCarouselPose(2.999, 300, 48, true).opacity, 0);
  assert.ok(Math.abs(getContinuousCarouselSlot(0, 3.0001, 6) - 2.9999) < 1e-6);
  assert.ok(Math.abs(getContinuousCarouselSlot(0, 2.9999, 6) + 2.9999) < 1e-6);
});

test('short-form: counter follows the video nearest the center, wrapping 06 → 01', () => {
  assert.equal(getFocusedCarouselIndex(0.4, 6), 0);
  assert.equal(getFocusedCarouselIndex(0.6, 6), 1);
  assert.equal(getFocusedCarouselIndex(5.6, 6), 0);
  assert.equal(getFocusedCarouselIndex(-0.6, 6), 5);
});

test('short-form: center and side videos play, far ones pause', () => {
  assert.equal(shouldCarouselVideoPlay(0), true);
  assert.equal(shouldCarouselVideoPlay(-1), true);
  assert.equal(shouldCarouselVideoPlay(1.6), false);
});

test('long-form flow: cards rise (phase decreases) and wrap at the invisible far end', async () => {
  const { getLongFormFlowPhase, getLongFormFlowPose } = await import('../lib/motionHelpers');
  const total = 6;
  const a = getLongFormFlowPhase(1, 1, total);
  const b = getLongFormFlowPhase(1, 1.25, total);
  assert.equal(a, 0);
  assert.ok(b < a, 'phase decreases → y decreases → card moves up');
  assert.ok(getLongFormFlowPose(b, 200).y < getLongFormFlowPose(a, 200).y);
  // the seam (±3 slots) is fully transparent on both sides
  assert.equal(getLongFormFlowPose(-2.99, 200).opacity, 0);
  assert.equal(getLongFormFlowPose(2.99, 200).opacity, 0);
});

test('long-form flow keeps the original three-card stack at whole slots', async () => {
  const { getLongFormFlowPose } = await import('../lib/motionHelpers');
  for (const slot of [-1, 0, 1]) {
    const flow = getLongFormFlowPose(slot, 200);
    const orig = getLongFormLoopPose(slot, 200);
    assert.equal(flow.y, orig.y);
    assert.equal(flow.scale, orig.scale);
    assert.equal(flow.opacity, orig.opacity);
  }
  assert.ok(getLongFormFlowPose(0, 200).zIndex > getLongFormFlowPose(-1, 200).zIndex);
});

test('long-form autoplay follows the front card as the stack moves', async () => {
  const { getLongFormFlowPhase, getLongFormFlowPose } = await import('../lib/motionHelpers');
  const frontCards = (offset: number) => Array.from({ length: 6 }, (_, index) => index)
    .filter((index) => getLongFormFlowPose(getLongFormFlowPhase(index, offset, 6), 200).isFront);
  assert.deepEqual(frontCards(1), [1]);
  assert.deepEqual(frontCards(1.6), [2]);
  assert.deepEqual(frontCards(5.6), [0]);
});

test('long-form flow motion is continuous: no jump between neighbouring phases', async () => {
  const { getLongFormFlowPose } = await import('../lib/motionHelpers');
  for (let p = -2.9; p < 2.9; p += 0.01) {
    const a = getLongFormFlowPose(p, 200);
    const b = getLongFormFlowPose(p + 0.01, 200);
    assert.ok(Math.abs(a.y - b.y) <= 2.5, `y jump at ${p}`);
    assert.ok(Math.abs(a.opacity - b.opacity) <= 0.05, `opacity jump at ${p}`);
    assert.ok(Math.abs(a.scale - b.scale) <= 0.01, `scale jump at ${p}`);
  }
});

test('long-form crossing wipe peaks exactly at the front-card hand-off', async () => {
  const { getLongFormCrossingWipe } = await import('../lib/motionHelpers');
  assert.equal(getLongFormCrossingWipe(-0.5), 1);
  assert.equal(getLongFormCrossingWipe(0), 0);
  assert.equal(getLongFormCrossingWipe(-1), 0);
  assert.ok(getLongFormCrossingWipe(-0.45) > 0 && getLongFormCrossingWipe(-0.45) < 1);
});

test('note connector joins zigzag notes edge to edge across the column gap', async () => {
  const { getNoteConnectorPath } = await import('../lib/motionHelpers');
  const d = getNoteConnectorPath([
    { left: 0, top: 0, width: 400, height: 300 },
    { left: 600, top: 200, width: 400, height: 300 },
    { left: 40, top: 420, width: 400, height: 300 },
  ]);
  // 01 → 02: leaves 01's right edge (x=400), lands on 02's top edge beside its pin
  assert.ok(d.startsWith('M400 126 '), d);
  assert.ok(d.includes(' 680 200 M'), d);
  // 02 → 03: leaves 02's left edge, lands on 03's top edge (right of its pin)
  assert.ok(d.includes('M600 326 '), d);
  assert.ok(d.endsWith(' 360 420'), d);
});

test('note connector links stacked notes through the gap between them', async () => {
  const { getNoteConnectorPath } = await import('../lib/motionHelpers');
  const d = getNoteConnectorPath([
    { left: 0, top: 0, width: 300, height: 200 },
    { left: 10, top: 240, width: 300, height: 200 },
  ]);
  assert.ok(d.startsWith('M216 200 '), d);
  assert.ok(d.endsWith(' 94 240'), d);
  assert.equal(getNoteConnectorPath([{ left: 0, top: 0, width: 1, height: 1 }]), '');
});

test('testimonial marquee keeps a steady pixel speed across loop widths', () => {
  assert.equal(getMarqueeDuration(5064, 36), 140.7);
  assert.equal(getMarqueeDuration(3864, 36), 107.3);
  assert.equal(getMarqueeDuration(0, 36), 120);
});

test('marquee pause/resume ramps smoothly between rates', () => {
  assert.equal(rampPlaybackRate(1, 0, 0), 1);
  assert.equal(rampPlaybackRate(1, 0, 0.5), 0.5);
  assert.equal(rampPlaybackRate(1, 0, 1), 0);
  assert.equal(rampPlaybackRate(0, 1, 2), 1);
  assert.ok(rampPlaybackRate(0, 1, 0.25) < 0.25);
});
