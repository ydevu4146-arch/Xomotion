import { describe, expect, it } from 'vitest';
import {
  CUSTOM_PACKAGE,
  DEFAULT_MARKET,
  PRICING_PACKAGES,
  getPackageById,
  getPackagePrice,
  inquirySchema,
} from '../lib/pricing';

describe('pricing packages', () => {
  it('shows exactly three priced cards in order', () => {
    expect(PRICING_PACKAGES.map((p) => p.name)).toEqual(['BASIC', 'STANDARD', 'PREMIUM']);
  });

  it('defaults to India', () => {
    expect(DEFAULT_MARKET).toBe('IN');
  });

  it('uses the exact India prices', () => {
    expect(getPackagePrice('basic', 'IN')).toBe('₹599');
    expect(getPackagePrice('standard', 'IN')).toBe('₹1,099');
    expect(getPackagePrice('premium', 'IN')).toBe('₹2,999');
  });

  it('uses the exact USA prices', () => {
    expect(getPackagePrice('basic', 'US')).toBe('$99');
    expect(getPackagePrice('standard', 'US')).toBe('$199');
    expect(getPackagePrice('premium', 'US')).toBe('$599');
  });

  it('keeps Custom without a fixed price in both markets', () => {
    expect(CUSTOM_PACKAGE.prices).toEqual({ IN: "Let's Discuss", US: "Let's Discuss" });
    expect(CUSTOM_PACKAGE.heading).toBe('Need Something Custom?');
    expect(CUSTOM_PACKAGE.cta).toBe('Get Custom Pricing');
  });

  it('only Standard is marked most popular', () => {
    expect(PRICING_PACKAGES.filter((p) => p.popular).map((p) => p.id)).toEqual(['standard']);
  });

  it('keeps the exact deliverables', () => {
    expect(getPackageById('basic').deliverables).toEqual([
      'Clean cuts & transitions', 'Basic captions', 'Background music', 'Basic color correction', '1 revision',
    ]);
    expect(getPackageById('standard').deliverables).toEqual([
      'Advanced transitions', 'Animated captions', 'Professional color grading', 'Sound design', 'Motion graphics', '2 revisions',
    ]);
    expect(getPackageById('premium').deliverables).toEqual([
      'Cinematic editing', 'Advanced motion graphics', 'Custom animations', 'Premium sound design', 'Advanced storytelling', '3 revisions',
    ]);
  });

  it('uses the requested button labels', () => {
    expect(PRICING_PACKAGES.map((p) => p.cta)).toEqual(['GET STARTED', 'CHOOSE STANDARD', 'GO PREMIUM']);
  });
});

describe('inquiry form rules', () => {
  const base = { package: 'standard' as const, fullName: 'Asha Rao', email: 'asha@example.com' };

  it('accepts a package inquiry with only name and email, defaulting to India', () => {
    const r = inquirySchema.safeParse(base);
    expect(r.success).toBe(true);
    expect(r.success && r.data.country).toBe('IN');
  });

  it('accepts USA as the country', () => {
    const r = inquirySchema.safeParse({ ...base, country: 'US' });
    expect(r.success && r.data.country).toBe('US');
  });

  it('rejects any other country', () => {
    expect(inquirySchema.safeParse({ ...base, country: 'UK' }).success).toBe(false);
  });

  it('requires a valid email', () => {
    expect(inquirySchema.safeParse({ ...base, email: 'nope' }).success).toBe(false);
  });

  it('requires a name', () => {
    expect(inquirySchema.safeParse({ ...base, fullName: '  ' }).success).toBe(false);
  });

  it('requires at least one service for a custom quote', () => {
    expect(inquirySchema.safeParse({ ...base, package: 'custom' }).success).toBe(false);
    expect(inquirySchema.safeParse({ ...base, package: 'custom', services: ['Graphic design'] }).success).toBe(true);
  });
});
