import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const migration = readFileSync("drizzle/migrations/0003_restrict_portfolio_public_reads.sql", "utf8");
const publicPolicy = migration.split('CREATE POLICY "published portfolio read"')[1]?.split(";")[0] ?? "";
const storagePolicy = migration.split('CREATE POLICY "portfolio owner read"')[1] ?? "";

describe("Portfolio access boundaries", () => {
  it("publishes only the replacement slots used by portfolio cards", () => {
    const short = readFileSync("src/components/ShortFormSection.tsx", "utf8");
    const long = readFileSync("src/components/LongFormSection.tsx", "utf8");
    const designs = readFileSync("src/components/GraphicDesignSection.tsx", "utf8");
    const cardSlots = [
      ...[...`${short}\n${long}`.matchAll(/videoSrc: mediaUrl\('([^']+)'\)/g)].map((match) => match[1]),
      ...[...designs.matchAll(/file: '(design-[^']+)'/g)].map((match) => match[1]),
    ].sort();
    const publishedSlots = [...publicPolicy.matchAll(/'([^']+)'/g)].map((match) => match[1]).sort();
    expect(cardSlots).toHaveLength(17);
    expect(publishedSlots).toEqual(cardSlots);
    expect(publicPolicy).toContain("slot IN (");
    expect(publicPolicy).not.toMatch(/USING\s*\(\s*true\s*\)/i);
  });

  it("restricts private storage reads to the signed-in administrator's own files", () => {
    expect(migration).toContain('DROP POLICY "portfolio read" ON storage.objects');
    expect(storagePolicy).toContain("FOR SELECT TO authenticated");
    expect(storagePolicy).not.toMatch(/\banon\b/);
    expect(storagePolicy).toContain("bucket_id = 'portfolio'");
    expect(storagePolicy).toContain("owner_id = (SELECT auth.uid()::text)");
    expect(storagePolicy).toContain("AND public.has_role((SELECT auth.uid()), 'admin'::public.app_role)");
  });

  it("preserves administrator reads for upload updates without changing other access rules", () => {
    expect(migration).toContain('CREATE POLICY "admin read" ON public.media_overrides');
    expect(migration).toContain("USING (public.has_role((SELECT auth.uid()), 'admin'::public.app_role))");
    expect(migration).not.toMatch(/quote_requests|user_roles|grant_first_admin|CREATE FUNCTION|DROP TABLE/);
  });
});