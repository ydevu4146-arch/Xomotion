import { describe, expect, it } from 'vitest';
import { inquirySchema } from '@/lib/pricing';
import {
  LETS_TALK_URL,
  buildInquiryMessage,
  whatsappUrl,
} from '@/lib/whatsapp';

const parse = (input: unknown) => inquirySchema.parse(input);

describe('whatsapp links', () => {
  it("Let's Talk opens the official number with the intro message", () => {
    expect(LETS_TALK_URL.startsWith('https://wa.me/917617032284?text=')).toBe(true);
    const text = new URL(LETS_TALK_URL).searchParams.get('text');
    expect(text).toBe(
      "Hi xo.motion! I'm interested in your creative services. I'd like to discuss my project. Please let me know how we can get started.",
    );
  });

  it('round-trips a multi-line message through the URL', () => {
    const msg = 'Line 1\n*Bold:* ₹599 & more';
    expect(new URL(whatsappUrl(msg)).searchParams.get('text')).toBe(msg);
  });
});

describe('buildInquiryMessage', () => {
  it('includes every filled field with package and price', () => {
    const msg = buildInquiryMessage(
      parse({
        package: 'standard',
        country: 'IN',
        fullName: 'Asha Rao',
        email: 'asha@example.com',
        company: 'Rao Studio',
        services: ['Short-form video editing', 'Motion graphics'],
        quantity: '8',
        budget: '5000',
        timeline: '2 weeks',
        details: 'Reels for a product launch',
      }),
    );
    expect(msg).toContain('*Package:* Standard');
    expect(msg).toContain('*Price:* ₹1,099');
    expect(msg).toContain('*Name:* Asha Rao');
    expect(msg).toContain('*Email:* asha@example.com');
    expect(msg).toContain('*Country:* India');
    expect(msg).toContain('*Brand / Company:* Rao Studio');
    expect(msg).toContain('*Service:* Short-form video editing, Motion graphics');
    expect(msg).toContain('*Number of videos / designs:* 8');
    expect(msg).toContain('*Estimated budget:* ₹5000');
    expect(msg).toContain('*Project timeline:* 2 weeks');
    expect(msg).toContain('*Project requirements:*\nReels for a product launch');
  });

  it('uses the right fixed price for each package', () => {
    const base = { fullName: 'A', email: 'a@b.co', country: 'IN' };
    expect(buildInquiryMessage(parse({ ...base, package: 'basic' }))).toContain('₹599');
    expect(buildInquiryMessage(parse({ ...base, package: 'premium' }))).toContain('₹2,999');
  });

  it('leaves out fields the visitor did not fill in', () => {
    const msg = buildInquiryMessage(
      parse({ package: 'basic', fullName: 'A', email: 'a@b.co' }),
    );
    expect(msg).not.toContain('Brand / Company');
    expect(msg).not.toContain('Estimated budget');
    expect(msg).not.toContain('Project requirements');
    expect(msg).not.toContain('Service:');
  });

  it('labels custom inquiries as custom pricing', () => {
    const msg = buildInquiryMessage(
      parse({
        package: 'custom',
        country: 'US',
        fullName: 'Sam',
        email: 'sam@example.com',
        services: ['Graphic design'],
        budget: '800',
      }),
    );
    expect(msg).toContain('*Package:* Custom Pricing');
    expect(msg).toContain("*Price:* Custom pricing (let's discuss)");
    expect(msg).toContain('*Country:* USA');
    expect(msg).toContain('*Estimated budget:* $800');
  });
});
