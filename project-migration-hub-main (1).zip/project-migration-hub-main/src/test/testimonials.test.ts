import { describe, expect, it } from 'vitest';
import { TESTIMONIALS } from '../lib/testimonials';

/** The six reviews the client supplied verbatim, in the order they should scroll. */
const CLIENT_REVIEWS: { name: string; quote: string }[] = [
  {
    name: 'Olivia Bennett',
    quote:
      'The transitions, pacing, and overall storytelling were just on point. Excellent work!',
  },
  {
    name: 'Michael Anderson',
    quote:
      'Professional from start to finish. The final video exceeded our expectations.',
  },
  {
    name: 'Sophia Williams',
    quote:
      'Really impressed with the creativity and attention to detail. Everything looked clean and modern.',
  },
  {
    name: 'Ryan Thompson',
    quote:
      'Quick turnaround without compromising quality. Exactly what a growing brand needs.',
  },
  {
    name: 'Isabella Moore',
    quote:
      'The edits made our content look much more professional. Loved the overall experience.',
  },
  {
    name: 'Ethan Wilson',
    quote:
      'A reliable creative partner who understands branding, storytelling, and audience engagement.',
  },
];

describe('client reviews', () => {
  it('shows the six supplied reviews with their reviewer names', () => {
    for (const review of CLIENT_REVIEWS) {
      const card = TESTIMONIALS.find((t) => t.name === review.name);
      expect(card, `missing review by ${review.name}`).toBeDefined();
      expect(card?.quote).toBe(review.quote);
    }
  });

  it('keeps only the six supplied reviews', () => {
    expect(TESTIMONIALS).toHaveLength(6);
  });

  it('never carries a reviewer photo or avatar initials', () => {
    for (const t of TESTIMONIALS) {
      expect(t).not.toHaveProperty('photo');
      expect(t).not.toHaveProperty('initials');
      expect(t).not.toHaveProperty('placeholder');
    }
  });

  it('contains no sample reviews', () => {
    expect(TESTIMONIALS.filter((t) => t.demo)).toHaveLength(0);
  });
});
