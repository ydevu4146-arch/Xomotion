import { afterEach, expect, test, vi } from 'vitest';
import { observePreviewActivity, preparePreviewVideo } from '../lib/preview-performance';

afterEach(() => vi.restoreAllMocks());

test('preview preparation loads once and reloads an uploaded replacement', () => {
  const video = document.createElement('video');
  const load = vi.spyOn(video, 'load').mockImplementation(() => {});
  preparePreviewVideo(video, '/original.mp4');
  preparePreviewVideo(video, '/original.mp4');
  expect(load).toHaveBeenCalledTimes(1);
  expect(video.preload).toBe('metadata');
  preparePreviewVideo(video, '/uploaded.mp4');
  expect(load).toHaveBeenCalledTimes(2);
  expect(video.getAttribute('src')).toBe('/uploaded.mp4');
});

test('portfolio activity pauses outside the section and in hidden tabs', () => {
  let callback: IntersectionObserverCallback = () => {};
  const disconnect = vi.fn();
  vi.stubGlobal('IntersectionObserver', class {
    constructor(cb: IntersectionObserverCallback) { callback = cb; }
    observe() {}
    disconnect = disconnect;
  });
  let hidden = false;
  vi.spyOn(document, 'hidden', 'get').mockImplementation(() => hidden);
  const activity = vi.fn();
  const cleanup = observePreviewActivity(document.createElement('section'), activity);
  const intersect = (isIntersecting: boolean) => callback([{ isIntersecting } as IntersectionObserverEntry], {} as IntersectionObserver);
  intersect(true);
  expect(activity).toHaveBeenLastCalledWith(true);
  hidden = true;
  document.dispatchEvent(new Event('visibilitychange'));
  expect(activity).toHaveBeenLastCalledWith(false);
  hidden = false;
  document.dispatchEvent(new Event('visibilitychange'));
  expect(activity).toHaveBeenLastCalledWith(true);
  intersect(false);
  expect(activity).toHaveBeenLastCalledWith(false);
  cleanup();
  expect(disconnect).toHaveBeenCalledOnce();
  vi.unstubAllGlobals();
});