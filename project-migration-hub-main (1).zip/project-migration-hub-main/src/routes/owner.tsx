import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useIsAdmin } from "@/hooks/useIsAdmin";

export const Route = createFileRoute("/owner")({
  head: () => ({
    meta: [
      { title: "Owner sign in — xo.motion" },
      { name: "description", content: "Studio owner sign in to manage portfolio videos and designs." },
      { property: "og:title", content: "Owner sign in — xo.motion" },
      { property: "og:description", content: "Studio owner sign in to manage portfolio media." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: OwnerPage,
});

function OwnerPage() {
  const isAdmin = useIsAdmin();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    const res =
      mode === "in"
        ? await supabase.auth.signInWithPassword({ email, password })
        : await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${window.location.origin}/owner` } });
    setBusy(false);
    if (res.error) return setMsg(res.error.message);
    if (mode === "up" && !res.data.session) setMsg("Check your email to confirm, then sign in.");
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-4 text-foreground">
      <div className="w-full max-w-sm space-y-5">
        <h1 className="text-2xl font-semibold">Studio owner</h1>
        {isAdmin ? (
          <div className="space-y-4">
            <p className="text-muted-foreground">
              You're signed in. Open any Short form, Long form or Graphic design card on the home page and tap
              “Upload” to replace it.
            </p>
            <div className="flex gap-2">
              <Link to="/" className="rounded-md bg-primary px-4 py-2 text-primary-foreground">Go to site</Link>
              <button className="rounded-md border border-input px-4 py-2" onClick={() => supabase.auth.signOut()}>Sign out</button>
            </div>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-3">
            <input className="w-full rounded-md border border-input bg-background px-3 py-2" type="email" placeholder="Email" required value={email} onChange={(e) => setEmail(e.target.value)} />
            <input className="w-full rounded-md border border-input bg-background px-3 py-2" type="password" placeholder="Password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} />
            <button disabled={busy} className="w-full rounded-md bg-primary px-4 py-2 text-primary-foreground">
              {busy ? "…" : mode === "in" ? "Sign in" : "Create owner account"}
            </button>
            {msg && <p className="text-sm text-muted-foreground">{msg}</p>}
            <button type="button" className="text-sm text-muted-foreground underline" onClick={() => setMode(mode === "in" ? "up" : "in")}>
              {mode === "in" ? "First time? Create the owner account" : "Have an account? Sign in"}
            </button>
          </form>
        )}
      </div>
    </main>
  );
}
