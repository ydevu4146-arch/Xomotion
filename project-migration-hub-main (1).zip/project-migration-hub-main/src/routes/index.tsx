import { createFileRoute } from "@tanstack/react-router";
import XoMotionSite from "@/components/XoMotionSite";

const TITLE = "xo.motion — We Don’t Just Edit Videos. We Create Experiences.";
const DESCRIPTION =
  "xo.motion is a premium motion design studio crafting cinematic visuals, motion graphics, and editing for SaaS, AI startups, luxury brands, and creators.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: XoMotionSite,
});
