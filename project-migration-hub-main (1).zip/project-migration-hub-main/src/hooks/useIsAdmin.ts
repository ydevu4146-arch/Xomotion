import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export function useIsAdmin() {
  const [isAdmin, setIsAdmin] = useState(false);
  useEffect(() => {
    const check = async (uid?: string) => {
      if (!uid) return setIsAdmin(false);
      const { data } = await supabase.rpc("has_role", { _user_id: uid, _role: "admin" });
      setIsAdmin(Boolean(data));
    };
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => void check(s?.user.id));
    supabase.auth.getSession().then(({ data }) => check(data.session?.user.id));
    return () => sub.subscription.unsubscribe();
  }, []);
  return isAdmin;
}
