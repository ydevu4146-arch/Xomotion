import { z } from 'zod';

export type PackageId = 'basic' | 'standard' | 'premium' | 'custom';

/** Pricing markets. Each has its own fixed prices — never converted. */
export type Market = 'IN' | 'US';
export const MARKETS = ['IN', 'US'] as const;
export const DEFAULT_MARKET: Market = 'IN';
export const MARKET_LABELS: Record<Market, string> = { IN: 'India', US: 'USA' };
export const MARKET_CURRENCY: Record<Market, string> = { IN: 'INR ₹', US: 'USD $' };

export interface PricingPackage {
  id: PackageId;
  name: string;
  /** Extra heading shown above the price (Custom only). */
  heading?: string;
  /** Small caption above the price; omitted when there is no fixed price. */
  priceCaption?: string;
  /** Fixed price per market (no currency conversion). */
  prices: Record<Market, string>;
  description: string;
  deliverables: string[];
  cta: string;
  popular?: boolean;
}

export const PRICING_PACKAGES: PricingPackage[] = [
  {
    id: 'basic',
    name: 'BASIC',
    priceCaption: 'Starting at',
    prices: { IN: '₹599', US: '$99' },
    description:
      'Perfect for creators and individuals getting started with professional content.',
    deliverables: [
      'Clean cuts & transitions',
      'Basic captions',
      'Background music',
      'Basic color correction',
      '1 revision',
    ],
    cta: 'GET STARTED',
  },
  {
    id: 'standard',
    name: 'STANDARD',
    priceCaption: 'Starting at',
    prices: { IN: '₹1,099', US: '$199' },
    description:
      'For growing creators and brands looking for polished, engaging content.',
    deliverables: [
      'Advanced transitions',
      'Animated captions',
      'Professional color grading',
      'Sound design',
      'Motion graphics',
      '2 revisions',
    ],
    cta: 'CHOOSE STANDARD',
    popular: true,
  },
  {
    id: 'premium',
    name: 'PREMIUM',
    priceCaption: 'Starting at',
    prices: { IN: '₹2,999', US: '$599' },
    description:
      'For established brands looking for high-end creative production.',
    deliverables: [
      'Cinematic editing',
      'Advanced motion graphics',
      'Custom animations',
      'Premium sound design',
      'Advanced storytelling',
      '3 revisions',
    ],
    cta: 'GO PREMIUM',
  },
];

/** Custom work is offered below the cards, not as a priced card. */
export const CUSTOM_PACKAGE: PricingPackage = {
  id: 'custom',
  name: 'CUSTOM',
  heading: 'Need Something Custom?',
  prices: { IN: "Let's Discuss", US: "Let's Discuss" },
  description:
    "Every project is different. Let's build a package around your specific requirements, content volume, and creative vision.",
  deliverables: [],
  cta: 'Get Custom Pricing',
};

export const ALL_PACKAGES: PricingPackage[] = [...PRICING_PACKAGES, CUSTOM_PACKAGE];

export const INQUIRY_SERVICES = [
  'Short-form video editing',
  'Long-form video editing',
  'Graphic design',
  'Motion graphics',
  'YouTube thumbnails',
  'Social media creatives',
  'Other',
] as const;

export const PACKAGE_IDS = ['basic', 'standard', 'premium', 'custom'] as const;

const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max, { message: `Please keep this under ${max} characters` })
    .optional()
    .default('');

export const inquirySchema = z
  .object({
    package: z.enum(PACKAGE_IDS),
    country: z.enum(MARKETS).default(DEFAULT_MARKET),
    fullName: z
      .string()
      .trim()
      .min(1, { message: 'Please enter your name' })
      .max(100, { message: 'Please keep this under 100 characters' }),
    email: z
      .string()
      .trim()
      .min(1, { message: 'Please enter your email' })
      .email({ message: 'Please enter a valid email address' })
      .max(255, { message: 'Please keep this under 255 characters' }),
    company: optionalText(120),
    services: z.array(z.enum(INQUIRY_SERVICES)).max(INQUIRY_SERVICES.length).default([]),
    quantity: optionalText(60),
    budget: optionalText(60),
    timeline: optionalText(120),
    details: optionalText(2000),
  })
  .superRefine((value, ctx) => {
    if (value.package === 'custom' && value.services.length === 0) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['services'],
        message: 'Pick at least one service',
      });
    }
  });

export type InquiryInput = z.input<typeof inquirySchema>;
export type InquiryData = z.output<typeof inquirySchema>;

export function getPackageById(id: PackageId): PricingPackage {
  const found = ALL_PACKAGES.find((p) => p.id === id);
  return found ?? PRICING_PACKAGES[0] ?? CUSTOM_PACKAGE;
}

/** The fixed price a package shows in a market. */
export function getPackagePrice(id: PackageId, market: Market): string {
  return getPackageById(id).prices[market];
}
