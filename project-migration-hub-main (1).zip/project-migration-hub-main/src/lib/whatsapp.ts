import {
  MARKET_LABELS,
  getPackageById,
  type InquiryData,
} from '@/lib/pricing';

/** Official xo.motion WhatsApp number (digits only, with country code). */
export const WHATSAPP_NUMBER = '917617032284';
export const WHATSAPP_DISPLAY = '+91 7617032284';
export const CONTACT_EMAIL = 'xomotion02@gmail.com';
export const CONTACT_MAILTO = `mailto:${CONTACT_EMAIL}`;
export const WHATSAPP_BASE_URL = `https://wa.me/${WHATSAPP_NUMBER}`;

export const LETS_TALK_MESSAGE =
  "Hi xo.motion! I'm interested in your creative services. I'd like to discuss my project. Please let me know how we can get started.";

/** wa.me link with a pre-filled message. */
export function whatsappUrl(message: string): string {
  return `${WHATSAPP_BASE_URL}?text=${encodeURIComponent(message)}`;
}

/** Link every "Let's Talk" button uses. */
export const LETS_TALK_URL = whatsappUrl(LETS_TALK_MESSAGE);

const titleCase = (s: string) => s.charAt(0) + s.slice(1).toLowerCase();

function withCurrency(budget: string, country: InquiryData['country']): string {
  const symbol = country === 'US' ? '$' : '₹';
  return /^[₹$]/.test(budget) ? budget : `${symbol}${budget}`;
}

/**
 * Formats a validated inquiry into a readable WhatsApp message.
 * Only fields the visitor actually filled in are included.
 */
export function buildInquiryMessage(data: InquiryData): string {
  const pkg = getPackageById(data.package);
  const isCustom = data.package === 'custom';
  const price = isCustom
    ? "Custom pricing (let's discuss)"
    : `${pkg.prices[data.country]} (starting at)`;

  const rows: Array<[string, string]> = [
    ['Package', isCustom ? 'Custom Pricing' : titleCase(pkg.name)],
    ['Price', price],
    ['Name', data.fullName],
    ['Email', data.email],
    ['Country', MARKET_LABELS[data.country]],
    ['Brand / Company', data.company],
    ['Service', data.services.join(', ')],
    ['Number of videos / designs', data.quantity],
    ['Estimated budget', data.budget ? withCurrency(data.budget, data.country) : ''],
    ['Project timeline', data.timeline],
  ];

  const lines = [
    isCustom
      ? "Hi xo.motion! I'd like a custom quote for my project."
      : `Hi xo.motion! I'd like to enquire about the ${titleCase(pkg.name)} package.`,
    '',
    ...rows
      .filter(([, value]) => value.trim() !== '')
      .map(([label, value]) => `*${label}:* ${value.trim()}`),
  ];

  if (data.details.trim()) {
    lines.push('', '*Project requirements:*', data.details.trim());
  }

  return lines.join('\n');
}

/**
 * Opens WhatsApp in a new tab (must run inside the click/submit handler so
 * browsers allow it); falls back to navigating this tab if popups are blocked.
 */
export function openWhatsApp(url: string): void {
  const win = window.open(url, '_blank');
  if (win) {
    win.opener = null;
  } else {
    window.location.href = url;
  }
}
