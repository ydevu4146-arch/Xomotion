import { useEffect, useSyncExternalStore } from "react";
import { supabase } from "@/integrations/supabase/client";
import { mediaUrl } from "@/lib/media";

/** Live map of slot filename -> uploaded replacement URL. */
let overrides: Record<string, string> = {};
let loaded = false;
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());

const pointers = import.meta.glob<{ url: string }>("../assets/media/*.asset.json", { eager: true, import: "default" });
const slotByUrl: Record<string, string> = {};
for (const [path, p] of Object.entries(pointers)) {
  const name = path.split("/").pop()!.replace(/\.asset\.json$/, "");
  slotByUrl[p.url] = name;
}

export function slotOf(url: string): string {
  return slotByUrl[url] ?? url;
}

export async function refreshOverrides() {
  const { data } = await supabase.from("media_overrides").select("slot,url");
  overrides = Object.fromEntries((data ?? []).map((r) => [r.slot, r.url]));
  loaded = true;
  emit();
}

export function useMediaOverrides() {
  const map = useSyncExternalStore(
    (cb) => (listeners.add(cb), () => listeners.delete(cb)),
    () => overrides,
    () => overrides,
  );
  useEffect(() => {
    if (!loaded) void refreshOverrides();
  }, []);
  /** Resolve a default media URL (or slot filename) to its current URL. */
  const resolve = (urlOrSlot: string) => {
    const slot = slotByUrl[urlOrSlot] ?? urlOrSlot;
    return map[slot] ?? (slotByUrl[urlOrSlot] ? urlOrSlot : mediaUrl(slot));
  };
  const isReplaced = (urlOrSlot: string) => Boolean(map[slotByUrl[urlOrSlot] ?? urlOrSlot]);
  return { resolve, isReplaced };
}

export async function uploadToSlot(slot: string, file: File) {
  const ext = file.name.split(".").pop() || "bin";
  const path = `${slot}/${Date.now()}.${ext}`;
  const up = await supabase.storage.from("portfolio").upload(path, file, { contentType: file.type, upsert: true });
  if (up.error) throw up.error;
  const signed = await supabase.storage.from("portfolio").createSignedUrl(path, 60 * 60 * 24 * 365 * 10);
  if (signed.error || !signed.data) throw signed.error ?? new Error("Could not create link");
  const { error } = await supabase.from("media_overrides").upsert({ slot, url: signed.data.signedUrl, updated_at: new Date().toISOString() });
  if (error) throw error;
  await refreshOverrides();
}
