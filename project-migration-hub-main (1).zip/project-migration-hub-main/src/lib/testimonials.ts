export interface Testimonial {
  quote: string;
  name: string;
  /** Job title shown under the name; omitted until the client supplies one. */
  role?: string;
  /** Sample card, labelled on the site, until real client feedback is supplied. */
  demo?: boolean;
}

export const TESTIMONIALS: Testimonial[] = [
  {
    quote:
      'The transitions, pacing, and overall storytelling were just on point. Excellent work!',
    name: 'Olivia Bennett',
  },
  {
    quote:
      'Professional from start to finish. The final video exceeded our expectations.',
    name: 'Michael Anderson',
  },
  {
    quote:
      'Really impressed with the creativity and attention to detail. Everything looked clean and modern.',
    name: 'Sophia Williams',
  },
  {
    quote:
      'Quick turnaround without compromising quality. Exactly what a growing brand needs.',
    name: 'Ryan Thompson',
  },
  {
    quote:
      'The edits made our content look much more professional. Loved the overall experience.',
    name: 'Isabella Moore',
  },
  {
    quote:
      'A reliable creative partner who understands branding, storytelling, and audience engagement.',
    name: 'Ethan Wilson',
  },
];
