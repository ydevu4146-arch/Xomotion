import { createServerFn } from "@tanstack/react-start";
import { inquirySchema } from "@/lib/pricing";

/** Stores one validated project inquiry without exposing the private table publicly. */
export const submitInquiry = createServerFn({ method: "POST" })
  .validator((input: unknown) => inquirySchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin
      .from("quote_requests")
      .insert({
        package: data.package,
        country: data.country,
        full_name: data.fullName,
        email: data.email,
        company: data.company || null,
        services: data.services,
        quantity: data.quantity || null,
        budget: data.budget || null,
        timeline: data.timeline || null,
        details: data.details || null,
      })
      .select("id")
      .single();

    if (error || !row) {
      console.error("quote_requests insert failed", error);
      throw new Error("We could not send your request. Please try again.");
    }

    return { id: row.id };
  });