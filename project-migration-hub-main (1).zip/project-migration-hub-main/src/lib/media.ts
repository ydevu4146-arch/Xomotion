const pointers = import.meta.glob<{ url: string }>("../assets/media/*.asset.json", {
  eager: true,
  import: "default",
});

const byName: Record<string, string> = {};
for (const [path, pointer] of Object.entries(pointers)) {
  const filename = path.split("/").pop();
  if (filename) byName[filename.replace(/\.asset\.json$/, "")] = pointer.url;
}

export function mediaUrl(filename: string): string {
  const url = byName[filename];
  if (!url) throw new Error(`Missing media asset: ${filename}`);
  return url;
}