export interface RectBounds {
  left: number;
  top: number;
  width: number;
  height: number;
}

export function computeMagneticOffset(
  clientX: number,
  clientY: number,
  rect: RectBounds,
): { x: number; y: number } {
  const relX = clientX - rect.left - rect.width / 2;
  const relY = clientY - rect.top - rect.height / 2;
  return {
    x: relX * 0.25,
    y: relY * 0.35,
  };
}

export function computeTiltAngles(
  clientX: number,
  clientY: number,
  rect: RectBounds,
): { rotateX: number; rotateY: number } {
  if (rect.width === 0 || rect.height === 0) {
    return { rotateX: 0, rotateY: 0 };
  }
  const px = (clientX - rect.left) / rect.width - 0.5;
  const py = (clientY - rect.top) / rect.height - 0.5;
  return {
    rotateX: py * -6 || 0,
    rotateY: px * 8 || 0,
  };
}

export function nextCounterValue(
  current: number,
  target: number,
): { value: number; done: boolean } {
  const step = Math.max(1, Math.round(target / 60));
  const next = current + step;
  if (next >= target) {
    return { value: target, done: true };
  }
  return { value: next, done: false };
}

export function toggleFaqIndex(
  currentOpenIndex: number | null,
  clickedIndex: number,
): number | null {
  return currentOpenIndex === clickedIndex ? null : clickedIndex;
}

export function toggleMobileMenuState(currentlyOpen: boolean): boolean {
  return !currentlyOpen;
}

export function wrapProjectIndex(index: number, total: number): number {
  if (total <= 0) return 0;
  return ((index % total) + total) % total;
}

export function getRelativeCarouselSlot(
  cardIndex: number,
  activeIndex: number,
  total: number,
): number {
  if (total <= 0) return 0;
  const diff = wrapProjectIndex(cardIndex - activeIndex, total);
  if (diff <= 1) return diff; // 0 (active), +1 (adjacent visible right)
  if (diff === total - 1) return -1; // -1 (adjacent left)
  if (diff === total - 2) return -2; // -2 (off-screen left)
  return diff; // +2, +3 (off-screen right)
}

export function formatProjectCounter(index: number, total: number): string {
  const safeTotal = Math.max(1, total);
  const current = wrapProjectIndex(index, safeTotal) + 1;
  return `${String(current).padStart(2, '0')} / ${String(safeTotal).padStart(2, '0')}`;
}

export interface CarouselSlotPose {
  x: number;
  scale: number;
  rotateY: number;
  opacity: number;
  zIndex: number;
  blur: number;
  brightness: number;
}

export function getCarouselSlotPose(
  slot: number,
  frameWidth: number,
  gap: number,
  isMobile: boolean,
): CarouselSlotPose {
  const stepX = isMobile ? Math.round(frameWidth * 0.92 + gap) : frameWidth + gap;
  const farX = Math.round(stepX * 1.85);
  const sideScale = isMobile ? 0.78 : 0.82;
  const farScale = isMobile ? 0.64 : 0.68;
  const sideRotate = isMobile ? 15 : 18;
  const farRotate = isMobile ? 24 : 28;
  const sideBlur = isMobile ? 2.5 : 3;

  if (slot === 0) {
    return {
      x: 0,
      scale: 1,
      rotateY: 0,
      opacity: 1,
      zIndex: 30,
      blur: 0,
      brightness: 1,
    };
  }
  if (slot === 1) {
    return {
      x: stepX,
      scale: sideScale,
      rotateY: -sideRotate,
      opacity: 0.82,
      zIndex: 20,
      blur: sideBlur,
      brightness: 0.86,
    };
  }
  if (slot === -1) {
    return {
      x: -stepX,
      scale: sideScale,
      rotateY: sideRotate,
      opacity: 0.82,
      zIndex: 20,
      blur: sideBlur,
      brightness: 0.86,
    };
  }
  if (slot >= 2) {
    return {
      x: farX,
      scale: farScale,
      rotateY: -farRotate,
      opacity: 0,
      zIndex: 10,
      blur: 6,
      brightness: 0.72,
    };
  }
  return {
    x: -farX,
    scale: farScale,
    rotateY: farRotate,
    opacity: 0,
    zIndex: 10,
    blur: 6,
    brightness: 0.72,
  };
}

export interface LongFormStackPose {
  scale: number;
  opacity: number;
  brightness: number;
  zIndex: number;
  transformOrigin: 'center bottom' | 'center center' | 'center top';
  labelPosition: 'top' | 'bottom';
}

export function getLongFormStackPose(
  index: number,
  activeIndex: number,
): LongFormStackPose {
  const distance = Math.abs(index - activeIndex);
  if (distance === 0) {
    return {
      scale: 1,
      opacity: 1,
      brightness: 1,
      zIndex: 30,
      transformOrigin: 'center center',
      labelPosition: 'top',
    };
  }
  const isAbove = index < activeIndex;
  return {
    scale: distance === 1 ? 0.91 : 0.83,
    opacity: distance === 1 ? 0.9 : 0.8,
    brightness: distance === 1 ? 0.86 : 0.76,
    zIndex: distance === 1 ? 20 : 10,
    transformOrigin: isAbove ? 'center bottom' : 'center top',
    labelPosition: isAbove ? 'top' : 'bottom',
  };
}

export function getYouTubeEmbedUrl(input?: string | null): string | null {
  if (!input) return null;
  const trimmed = input.trim();
  if (!trimmed) return null;

  let videoId: string | null = null;
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
    videoId = trimmed;
  } else {
    const match = trimmed.match(
      /(?:youtube(?:-nocookie)?\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/,
    );
    if (match?.[1]) {
      videoId = match[1];
    }
  }

  if (!videoId) return null;
  return `https://www.youtube-nocookie.com/embed/${videoId}?rel=0&modestbranding=1&enablejsapi=1`;
}

function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = Math.max(0, Math.min(1, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}

export function wrapLoopPhase(rawPhase: number, total = 3): number {
  const half = total / 2;
  return ((((rawPhase + half) % total) + total) % total) - half;
}

export interface LongFormLoopPose {
  phase: number;
  y: number;
  scale: number;
  opacity: number;
  brightness: number;
  zIndex: number;
  isFront: boolean;
  topLabelOpacity: number;
  bottomLabelOpacity: number;
}

export function getLongFormLoopPose(
  rawPhase: number,
  stepY: number,
  total = 3,
): LongFormLoopPose {
  const phase = wrapLoopPhase(rawPhase, total);
  const absP = Math.abs(phase);

  const innerT = Math.min(absP, 1);
  const cosEase = 0.5 - 0.5 * Math.cos(Math.PI * innerT);
  const scale =
    absP <= 1
      ? 1 - 0.09 * cosEase
      : 0.91 - 0.07 * Math.min(1, (absP - 1) / 0.5);

  const brightness =
    absP <= 1
      ? 1 - 0.14 * cosEase
      : 0.86 - 0.1 * Math.min(1, (absP - 1) / 0.5);

  const opacity =
    absP <= 1
      ? 1 - 0.1 * cosEase
      : 0.9 * (1 - smoothstep(1.12, 1.48, absP));

  const zIndex = Math.round(100 - absP * 60);
  const isFront = absP < 0.5;

  const cross = smoothstep(0.18, 0.42, phase);
  const topLabelOpacity = 1 - cross;
  const bottomLabelOpacity = cross;

  return {
    phase,
    y: phase * stepY,
    scale,
    opacity,
    brightness,
    zIndex,
    isFront,
    topLabelOpacity,
    bottomLabelOpacity,
  };
}

export function getLongFormTransitionZIndex(
  prevPhase: number,
  nextPhase: number,
): number {
  if (Math.abs(nextPhase) < 0.5) return 100;
  if (Math.abs(nextPhase - prevPhase) > 1.2) return 25;
  return 50;
}

export interface LongFormScrollPose {
  y: number;
  scale: number;
  rotationX: number;
  separation: number;
  focus: number;
  shadowY: number;
  shadowBlur: number;
  shadowAlpha: number;
  ringAlpha: number;
}

/**
 * Scroll-controlled cinematic pose for a long-form card, layered on top of
 * its base stack position. `progress` is 0 when the section enters from the
 * bottom of the viewport and 1 when it leaves through the top; the result is a
 * pure function of progress, so scrolling back up restores the stacked pose.
 */
export function getLongFormScrollPose(
  phase: number,
  progress: number,
  stepY: number,
  isMobile = false,
): LongFormScrollPose {
  const p = Math.min(1, Math.max(0, progress));
  const depth = Math.min(1, Math.abs(phase));
  const focus = 1 - depth;
  const separation = smoothstep(0.06, 0.42, p);
  const stacked = 1 - separation;

  // stacked: background cards tucked toward the focused card
  const compressY = -phase * stepY * 0.22 * stacked;
  // parallax: background cards drift slower than the page, front stays anchored
  const parallaxRange = stepY * (isMobile ? 0.1 : 0.16);
  const parallaxY = (p - 0.5) * parallaxRange * depth * Math.sign(phase || 0) * -1;

  const scale = 1 + 0.05 * separation * focus - 0.035 * stacked * depth;
  const rotationX = -phase * (isMobile ? 2.5 : 4) * stacked + (0.5 - p) * 2 * separation * depth || 0;

  const lift = separation * focus;
  return {
    y: compressY + parallaxY || 0,
    scale,
    rotationX,
    separation,
    focus,
    shadowY: 22 + 14 * focus + 12 * lift,
    shadowBlur: 48 + 36 * focus + 24 * lift,
    shadowAlpha: 0.24 + 0.14 * focus + 0.06 * lift + 0.06 * depth * stacked,
    ringAlpha: 0.18 * focus,
  };
}

// ---------------------------------------------------------------------------
// LONG-FORM VIDEOS — continuous bottom → top flow
// ---------------------------------------------------------------------------

/** Upward drift of the long-form stack, in card slots per second. */
export const LONG_FORM_FLOW_SPEED = 0.1;
/** Whole copies of the video list rendered, so the wrap seam is always invisible. */
export const LONG_FORM_FLOW_COPIES = 2;
/** Half-width (in slots) of the overlap wipe around the front-card hand-off. */
export const LONG_FORM_CROSS_WINDOW = 0.2;

/**
 * Phase of card `index` when the stack has travelled `offset` slots upward.
 * Phase 0 = centre, −1 = top slot, +1 = bottom slot; it decreases over time,
 * so cards rise. Wrapped into [−total/2, total/2).
 */
export function getLongFormFlowPhase(index: number, offset: number, total: number): number {
  return wrapLoopPhase(index - offset, total);
}

/**
 * Pose for a flowing long-form card. Within ±1 slot it is exactly the original
 * three-card stack pose; beyond that the card keeps travelling (decelerating),
 * shrinks, dims and fades out so it leaves through the top / arrives at the
 * bottom without a visible reset.
 */
export function getLongFormFlowPose(phase: number, stepY: number): LongFormLoopPose {
  const absP = Math.abs(phase);
  if (absP <= 1) {
    const base = getLongFormLoopPose(phase, stepY, 1000);
    return { ...base, zIndex: Math.round((100 - absP * 60) * 10) };
  }
  const sign = Math.sign(phase);
  const u = absP - 1;
  // keeps moving at the same speed as it passes the outer slot, then eases to a
  // stop just past it while shrinking — so it recedes inside the stack bounds
  const reach = 0.12;
  const travel = 1 + reach * (1 - Math.exp(-u / reach));
  const shrink = smoothstep(0, 1, u);
  const opacity = 0.9 * (1 - smoothstep(0, 0.8, u));
  const z = Math.max(1, Math.round((100 - absP * 60) * 10));
  return {
    phase,
    y: sign * travel * stepY,
    scale: 0.91 - 0.12 * shrink,
    opacity,
    brightness: 0.86 - 0.12 * Math.min(1, u),
    zIndex: z,
    isFront: false,
    topLabelOpacity: sign < 0 ? 1 : 0,
    bottomLabelOpacity: sign < 0 ? 0 : 1,
  };
}

/**
 * Hand-off wipe for the card just above centre. When a rising card meets the
 * next one at phase −0.5 / +0.5 their stacking order must swap; the upper card's
 * overlap is swept away bottom → top (t → 1) so the swap itself is never visible.
 */
export function getLongFormCrossingWipe(phase: number, window = LONG_FORM_CROSS_WINDOW): number {
  const d = Math.abs(phase + 0.5);
  if (d >= window) return 0;
  return 1 - smoothstep(0, window, d);
}

/**
 * Cursor-following parallax for a gallery card: returns a translate offset in px
 * that moves the image with the pointer, capped at ±strength. Center = 0.
 */
export function computeParallaxOffset(
  clientX: number,
  clientY: number,
  rect: RectBounds,
  strength = 12,
): { x: number; y: number } {
  if (rect.width === 0 || rect.height === 0) return { x: 0, y: 0 };
  const px = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width)) - 0.5;
  const py = Math.min(1, Math.max(0, (clientY - rect.top) / rect.height)) - 0.5;
  return { x: px * 2 * strength || 0, y: py * 2 * strength || 0 };
}

/**
 * Turns a horizontal swipe into a gallery step: swipe left → next (+1),
 * swipe right → previous (-1). Short or mostly vertical gestures → 0.
 */
export function getSwipeStep(dx: number, dy: number, threshold = 50): -1 | 0 | 1 {
  if (Math.abs(dx) < threshold || Math.abs(dx) <= Math.abs(dy)) return 0;
  return dx < 0 ? 1 : -1;
}

/**
 * Horizontal gap between short-form carousel cards. Mobile (≤768px) keeps its
 * fixed 18px; tablet/desktop grow fluidly with the viewport between 48px and 72px.
 */
export function getCarouselGap(viewportWidth: number): number {
  if (viewportWidth <= 768) return 18;
  return Math.min(72, Math.max(48, Math.round(viewportWidth * 0.035)));
}

/* ===== GRAPHIC DESIGN infinite showcase ===== */

export interface ShowcaseMetrics {
  cardW: number;
  cardH: number;
  gap: number;
  /** Distance between neighbouring card centers. */
  step: number;
  /** Auto-scroll speed in px per second (right → left). */
  speed: number;
  /** Max Y rotation (deg) of cards at the stage edges — the curve strength. */
  maxRotate: number;
  perspective: number;
}

export function getShowcaseMetrics(viewportW: number): ShowcaseMetrics {
  const w = Math.max(320, viewportW);
  let cardW: number;
  let gap: number;
  let speed: number;
  let maxRotate: number;
  let perspective: number;
  if (w <= 768) {
    cardW = Math.round(Math.min(260, Math.max(150, w * 0.52)));
    gap = 16;
    speed = 30;
    maxRotate = 16;
    perspective = 900;
  } else if (w < 1200) {
    cardW = Math.round(Math.min(290, Math.max(210, w * 0.27)));
    gap = 26;
    speed = 36;
    maxRotate = 20;
    perspective = 1300;
  } else {
    cardW = Math.round(Math.min(340, Math.max(260, w * 0.2)));
    gap = 32;
    speed = 42;
    maxRotate = 24;
    perspective = 1700;
  }
  return { cardW, cardH: Math.round(cardW * 1.25), gap, step: cardW + gap, speed, maxRotate, perspective };
}

/**
 * How many cards to render so the loop never shows a gap: a whole number of
 * project sequences (so order is preserved across the seam), with the seam
 * (half the loop length) always at least one card beyond the screen edge.
 */
export function getShowcaseSlotCount(viewportW: number, step: number, total: number): number {
  if (total <= 0 || step <= 0) return 0;
  const copies = Math.max(2, Math.ceil((viewportW + 2 * step) / (total * step)));
  return copies * total;
}

/**
 * Horizontal center of card `slot` relative to the stage center, given the
 * running scroll offset. Wraps into [-L/2, L/2) where L = slots × step, so the
 * stream is endless and every card keeps a constant spacing.
 */
export function getShowcaseSlotX(slot: number, step: number, offset: number, slots: number): number {
  const loop = slots * step;
  if (loop <= 0) return 0;
  const half = loop / 2;
  return ((((slot * step - offset + half) % loop) + loop) % loop) - half;
}

export interface ShowcasePose {
  rotateY: number;
  scale: number;
  opacity: number;
  zIndex: number;
}

/**
 * Curved 3D pose for a card at horizontal position `x` (px from stage center):
 * the center card is largest and flat, side cards turn inward like the inside
 * of a gentle cylinder and fade toward the edges.
 */
export function getShowcasePose(x: number, halfWidth: number, maxRotate: number): ShowcasePose {
  const u = halfWidth > 0 ? x / halfWidth : 0;
  const a = Math.min(Math.abs(u), 1.4);
  const curve = Math.min(a, 1.15);
  const fade = a <= 0.82 ? 0 : Math.min(1, (a - 0.82) / 0.5);
  return {
    rotateY: -Math.sign(u) * curve * maxRotate || 0,
    scale: 1.06 - 0.16 * curve * (2 - curve) * 0.85,
    opacity: 1 - fade * 0.75,
    zIndex: Math.round(100 - a * 50),
  };
}

/* ===== SHORT-FORM continuous carousel ===== */

/** Auto-scroll speed of the short-form carousel, in videos per second (right → left). */
export const SHORT_FORM_SPEED = 0.16;

/**
 * Continuous slot of card `index` for a fractional carousel `position`, wrapped
 * into [-total/2, total/2). Position grows over time, so slots shrink and cards
 * travel right → left; the wrap happens at the far, invisible slots.
 */
export function getContinuousCarouselSlot(index: number, position: number, total: number): number {
  if (total <= 0) return 0;
  const half = total / 2;
  return ((((index - position + half) % total) + total) % total) - half;
}

/** The video closest to the center for a fractional position — drives the counter and title. */
export function getFocusedCarouselIndex(position: number, total: number): number {
  return wrapProjectIndex(Math.round(position), total);
}

/** Visible videos near the center keep playing as they glide; far ones pause. */
export function shouldCarouselVideoPlay(slot: number): boolean {
  return Math.abs(slot) < 1.25;
}

/**
 * Pose for a fractional slot, blending the fixed slot poses so size, tilt, blur
 * and depth change smoothly as each video glides into and out of focus.
 * Horizontal position is interpolated linearly so the travel speed stays constant.
 */
export function getContinuousCarouselPose(
  slot: number,
  frameWidth: number,
  gap: number,
  isMobile: boolean,
): CarouselSlotPose {
  const s = Math.max(-2, Math.min(2, slot));
  const lo = Math.floor(s);
  const hi = Math.min(2, lo + 1);
  const t = s - lo;
  const a = getCarouselSlotPose(lo, frameWidth, gap, isMobile);
  const b = getCarouselSlotPose(hi, frameWidth, gap, isMobile);
  const e = t * t * (3 - 2 * t);
  const mix = (x: number, y: number, w: number) => x + (y - x) * w;
  return {
    x: mix(a.x, b.x, t),
    scale: mix(a.scale, b.scale, e),
    rotateY: mix(a.rotateY, b.rotateY, e),
    opacity: mix(a.opacity, b.opacity, e),
    zIndex: Math.round(30 - Math.min(2, Math.abs(slot)) * 10),
    blur: mix(a.blur, b.blur, e),
    brightness: mix(a.brightness, b.brightness, e),
  };
}

// ---------------------------------------------------------------------------
// WHY BRANDS CHOOSE — pinned-notes connector
// ---------------------------------------------------------------------------

export interface NoteBox {
  left: number;
  top: number;
  width: number;
  height: number;
}

/**
 * Curved path linking pinned notes in order. Side-by-side (zigzag) notes are
 * joined edge to edge across the gap between columns; notes stacked in one
 * column are joined bottom → top through the gap between them. Endpoints always
 * sit on a card edge, so the line only shows in the spaces between cards.
 */
export function getNoteConnectorPath(boxes: NoteBox[]): string {
  if (boxes.length < 2) return '';
  const r = (n: number) => Math.round(n * 10) / 10;
  let d = '';
  for (let i = 0; i < boxes.length - 1; i++) {
    const a = boxes[i];
    const b = boxes[i + 1];
    if (!a || !b) continue;
    const aCx = a.left + a.width / 2;
    const bCx = b.left + b.width / 2;
    const sideBySide = Math.abs(aCx - bCx) > Math.min(a.width, b.width) * 0.6;
    let sx: number, sy: number, ex: number, ey: number, c1x: number, c1y: number, c2x: number, c2y: number;
    if (sideBySide) {
      // leave the facing side, arc across the gap and land on the next note's
      // top edge beside its pin — like a thread strung between pinned notes
      const goingRight = bCx > aCx;
      sx = goingRight ? a.left + a.width : a.left;
      sy = a.top + a.height * 0.42;
      ex = goingRight ? b.left + b.width * 0.2 : b.left + b.width * 0.8;
      ey = b.top;
      c1x = sx + (ex - sx) * 0.72;
      c1y = sy - (ey - sy) * 0.15;
      c2x = ex;
      c2y = ey - Math.max(24, (ey - sy) * 0.55);
    } else {
      sx = aCx + a.width * 0.22;
      sy = a.top + a.height;
      ex = bCx - b.width * 0.22;
      ey = b.top;
      const dy = ey - sy;
      c1x = sx;
      c1y = sy + dy * 0.6;
      c2x = ex;
      c2y = ey - dy * 0.6;
    }
    d += `${i === 0 ? 'M' : ' M'}${r(sx)} ${r(sy)} C${r(c1x)} ${r(c1y)} ${r(c2x)} ${r(c2y)} ${r(ex)} ${r(ey)}`;
  }
  return d;
}

/** Seconds one marquee loop should take so it moves at a steady pixel speed. */
export function getMarqueeDuration(loopWidth: number, pxPerSecond: number, fallback = 120): number {
  if (!(loopWidth > 0) || !(pxPerSecond > 0)) return fallback;
  return Math.round((loopWidth / pxPerSecond) * 10) / 10;
}

/** Eased in-between playback rate for smoothly pausing/resuming a marquee. */
export function rampPlaybackRate(from: number, to: number, progress: number): number {
  const t = Math.min(1, Math.max(0, progress));
  const eased = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
  return from + (to - from) * eased;
}
