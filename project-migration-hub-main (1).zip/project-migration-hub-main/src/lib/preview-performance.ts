/** Attach a preview source only when its portfolio section is approached. */
export function preparePreviewVideo(video: HTMLVideoElement, source: string) {
  if (video.getAttribute('src') === source) return;
  video.preload = 'metadata';
  video.src = source;
  video.load();
}

/** Suspend portfolio animation and decoding in hidden browser tabs. */
export function observePreviewActivity(section: HTMLElement, onActivity: (active: boolean) => void) {
  let inView = false;
  const update = () => onActivity(inView && !document.hidden);
  const observer = new IntersectionObserver(([entry]) => {
    inView = Boolean(entry?.isIntersecting);
    update();
  }, { rootMargin: '80px 0px' });
  observer.observe(section);
  document.addEventListener('visibilitychange', update);
  return () => {
    observer.disconnect();
    document.removeEventListener('visibilitychange', update);
    onActivity(false);
  };
}